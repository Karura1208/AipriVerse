let url ={
  "url": [
    {
      "name": "フラワーバズリウムコスモスピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1424201826810728479/IMG_7358.jpg?ex=68f58bcf&is=68f43a4f&hm=73448be5335bccf7749fed9bf42d55c5621fe0ec3d9551b20cda73b92e769e23&"
    },
    {
      "name": "フルーツソーダストロベリー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1403549023708778657/IMG_6848.jpg?ex=68f58ee3&is=68f43d63&hm=ab6e7c46486729fe9488cd9a2a9db901ebc5112d01befb47b911405b1eea8b54&"
    },
    {
      "name": "アニマルバズリウムプードルピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1403548906851401760/IMG_6847.jpg?ex=68f58ec8&is=68f43d48&hm=3a64d0338c0a8db3536febfcb3b3cadbc184cd5547243da731db3382b66b1dc3&"
    },
    {
      "name": "ポッピンハートバズリウム１５しゅうねん",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1396120443802619925/IMG_6614.jpg?ex=68f58f3c&is=68f43dbc&hm=217eace8e04972bd024669b1e31cddc6dc393668196b2b901d71f9e2a4aa5e2e&"
    },
    {
      "name": "ポッピンハートバズリウムプリうさ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1393207422532845628/IMG_8656.jpg?ex=68f58246&is=68f430c6&hm=03abda3fe1fd38d5da85b90ba8028ddfa862bd92ae925764b6553d18e77dd1c1&"
    },
    {
      "name": "スペースバズリウムスターズピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1393205056131567657/IMG_6421.jpg?ex=68f58011&is=68f42e91&hm=2c6c46f18385f33e708c17a28d3185dbb8eb891ab6a121144eae6ed80555c5ee&"
    },
    {
      "name": "ウェルカムチェリーレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1383785633000063066/IMG_8546.jpg?ex=68f5828c&is=68f4310c&hm=6ed2e4ebdb980c9fc8caa8dabbbe42594bab3b04d2d9d98b0108b29c3a9071ec&"
    },
    {
      "name": "ピタTガール",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1373492046014320702/IMG_6072.jpg?ex=68f4f9e6&is=68f3a866&hm=44d75463d7468ffa537f868e94f4b10402d141b6d28eac088296e3b38a2f108d&"
    },
    {
      "name": "プリうさおでかけ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1373484325311615178/IMG_6069.jpg?ex=68f4f2b5&is=68f3a135&hm=e0940a2a98f839bc2514558b4a0fe48f1f83d085c6ad98150d2134009606c159&"
    },
    {
      "name": "ゆめみるリカちゃんコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1367044494196867093/IMG_8417.jpg?ex=68f54025&is=68f3eea5&hm=50daf2f042ce1a35e5a5bf253a74162189cebf8371d4be41096fed4290dd94d8&"
    },
    {
      "name": "キューティーラビットイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1367044118571647026/IMG_8414.jpg?ex=68f53fcc&is=68f3ee4c&hm=4e01d7805184edf35d32450435fe219d8fa24f6f0b06300628f8a001877806c1&"
    },
    {
      "name": "リトルツインスターズパーティーピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1367043652551180349/IMG_8411.jpg?ex=68f53f5d&is=68f3eddd&hm=95bc7d7021c89930e97d5b2495171de9a7df5a24d6dd971f49b865efc5a56043&"
    },
    {
      "name": "ジュエルバズリウムルビー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1358062343283806328/IMG_5612.jpg?ex=68f5885e&is=68f436de&hm=0494a8b78ac76f040212c5600ac4d5eeca9c54d061f9afd35a67c2e1420e9a64&"
    },
    {
      "name": "シークレットフレンズ∞バズリウムピュアホワイト",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1357327329499807834/IMG_5592.jpg?ex=68f57ed5&is=68f42d55&hm=fabf7dcf01d6e1c0dfaa79cc4bfdef90a0c82405de9ac1548c84a14932c1f5f5&"
    },
    {
      "name": "ロマンチックローズブルーム",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1357322695896731792/IMG_4032.jpg?ex=68f57a84&is=68f42904&hm=cf99693a1e346db9deed13fa2aa3fab2fd67cb08a168caf5f0805b5c3f568a5e&"
    },
    {
      "name": "ロマンチックリボンリボン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1357321927680856084/IMG_4031.jpg?ex=68f579cd&is=68f4284d&hm=5649ab801e28ec9214215e3d81e1a82442df521c1e92e60321f4581fde2bd525&"
    },
    {
      "name": "おえかきパレットるんるんイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1343486377500737556/IMG_5136.jpg?ex=68f53d71&is=68f3ebf1&hm=5562be79a8714d62fb33e0121fa662995bf01cae0c0819b4fe3e22a4d5331776&"
    },
    {
      "name": "ぴょんぴょんうさぎグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1337393930018488361/IMG_4821.jpg?ex=68f57ce8&is=68f42b68&hm=7ab7dd31e093e428826ef89313cd6e76d2c8d05a1445b5170d33e4446c10abb9&"
    },
    {
      "name": "ポッピンハートバズリウムブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1313493151847284746/IMG_7698.jpg?ex=68f58c92&is=68f43b12&hm=41f1949c68cb1661e038918ce4fe9fccbf345001463026550198f040d53b3d76&"
    },
    {
      "name": "ミラクルハロウィンピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1307341297694281728/IMG_3795.jpg?ex=68f4ebf6&is=68f39a76&hm=159b34eefff80e375c7dfddfa4a8325d3358059a04ef81b4240e0199c095ec73&"
    },
    {
      "name": "キャンディテーラード",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1304946316425826406/IMG_3728.jpg?ex=68f56ff6&is=68f41e76&hm=ae5b297d05b8dd4ef8c071335163969d5de071baefad2f49fc886c137cc0804d&"
    },
    {
      "name": "フレッシュレモンミント",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1294895867374862397/IMG_3331.jpg?ex=68f52100&is=68f3cf80&hm=93fefea4813daf21888115e0aa8c17e9fa85fe0ede912bc184efb3ae868a3cc1&"
    },
    {
      "name": "さわやかブルーシャボン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1290651806145318922/IMG_7440.jpg?ex=68f58269&is=68f430e9&hm=59c8d85e8d8c27da66947b7d2949097af57c6c498d0bfcf2db6da575b68a9e31&"
    },
    {
      "name": "マーメイドグランプリパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1286645768584695829/IMG_7371.jpg?ex=68f56fff&is=68f41e7f&hm=b8c4087e1b7ead9fbc31a76e2dc5eeda009129dd4bb66939640c4c983828b332&"
    },
    {
      "name": "ひまわりサマーレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1282321176999231570/IMG_7358.jpg?ex=68f58668&is=68f434e8&hm=d38525f4624a1e176fb0b7002ca9a12c9f78afc5c3f5d30327902a8c07fb2963&"
    },
    {
      "name": "ひまわりサマーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1280137233759993877/IMG_7330.jpg?ex=68f57d74&is=68f42bf4&hm=642235f0fe9e8536b6ff7fa7ca9334d361de2ce05f8fd296772c59d33b96c14f&"
    },
    {
      "name": "マーメイドグランプリピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1279782369976651816/IMG_2915.jpg?ex=68f58476&is=68f432f6&hm=6af98a3a4aea1ed564e96931c9094b408174c1e753e0dd53198f40a393ef339f&"
    },
    {
      "name": "シークレットフレンズ∞バズリウムピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1273998751668899853/IMG_7268.jpg?ex=68f4e94c&is=68f397cc&hm=d1470e544eb9b4d9a85f83d31de943dff1cef3146186ddb374bbc47dcb8ef161&"
    },
    {
      "name": "ハッピーチアフレッシュ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1273996849275211856/IMG_2710.jpg?ex=68f59046&is=68f43ec6&hm=3daa06fec6002aa040c26bbe6805f8d2e13512a0d4d2ea611447433954bb4642&"
    },
    {
      "name": "ウェルカムチェリーグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1273996428854689802/IMG_2708.jpg?ex=68f58fe2&is=68f43e62&hm=68e6fd55599e33b936b4d021c01a3da5785e00bfe463de20876d8598cd30e24d&"
    },
    {
      "name": "ラブリーアイドルイエローミント",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269167555260583946/IMG_7223.jpg?ex=68f52225&is=68f3d0a5&hm=33bce7f2580761b5853110d7b7ec498d249c239594a522ee7f783bc277fd0649&"
    },
    {
      "name": "スターパーティーいちこチョコ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269167524038311979/IMG_7222.jpg?ex=68f5221d&is=68f3d09d&hm=3533848210e14513b158bc3661165b2a6b8b1c594d86ef06c28413d0be63fd3f&"
    },
    {
      "name": "ハッピーチアグレープソーダ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269167384460001343/IMG_7220.jpg?ex=68f521fc&is=68f3d07c&hm=56bd224b389c6a7b98c8e92d5934f87ce589d4e24cbbf04811d9b2065d1ee9a6&"
    },
    {
      "name": "ひまわりサマー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269167183959949405/IMG_7215.jpg?ex=68f521cc&is=68f3d04c&hm=4dc813f5878d4ed93db9bd5bc571dfb73648e75ddc6198c242c11c552fed2ef0&"
    },
    {
      "name": "スターパーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269166065649188876/IMG_7209.jpg?ex=68f520c2&is=68f3cf42&hm=98090f956482abfb9514b82852f8536c2509d5266f06d0607cdd1865a4f42cc0&"
    },
    {
      "name": "ハッピーバースデーひまり",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1269165851550941289/IMG_7207.jpg?ex=68f5208e&is=68f3cf0e&hm=883d56e419274612cd4aef87908661df1fbbb35ec10b05728fe5ec2bf4e1058b&"
    },
    {
      "name": "ハッピーチアグレープソーダ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1264567879961940141/101_20240721212628.png?ex=68f589dd&is=68f4385d&hm=eb16219f5bfa72b81d6f17f50f38010e24885e3c3a39124c4d7627f207a116ea&"
    },
    {
      "name": "フレッシュレモンピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263473390388514888/IMG_7129.jpg?ex=68f5830a&is=68f4318a&hm=bed2c9acd4310fa1aaec0d8fee9fe47120c00aec5a3faf6b30666a5ac56591a5&"
    },
    {
      "name": "スターパーティーほしぞらブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263473319328612382/IMG_7125.jpg?ex=68f582f9&is=68f43179&hm=9464ec5d8fda9f9cdfcfa4120588d44d92a1d123ca1c2a7fceab52691b036620&"
    },
    {
      "name": "ハートメロディ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263469690022531202/IMG_2379.jpg?ex=68f57f98&is=68f42e18&hm=c7fa96d5dc329b17499835e95acf7b62860e8971c601701efb1ff19d650922d2&"
    },
    {
      "name": "フラワーチュール",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263469520056483840/IMG_2378.jpg?ex=68f57f6f&is=68f42def&hm=8edbd9aa89287223e058d3ac226c0864077bb81fbf6063666d3ddb3929a88390&"
    },
    {
      "name": "キューティーラビット",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263468940202348545/IMG_2376.jpg?ex=68f57ee5&is=68f42d65&hm=39d91d1d6b3c00635faa7989b3ba72567d89771299e0bc549006ea9be2efac95&"
    },
    {
      "name": "スターパーティーミントベリー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263461224725614644/IMG_1489.jpg?ex=68f577b5&is=68f42635&hm=b1418a54b2160140f8be2526ac1aab01c1ae7138fa5fc2a132399825e4aea279&"
    },
    {
      "name": "キューティーラビットブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263460203240620204/IMG_6868.jpg?ex=68f576c2&is=68f42542&hm=0433d5c3c4c7fd1ff366cade6d1d21f1857943d92ad542f8fdbce6fad694a34a&"
    },
    {
      "name": "ピンクジュエル",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263459668806864936/IMG_1129.jpg?ex=68f57642&is=68f424c2&hm=1cbef80d8d4dcab72847d11c1c2d4a3b4355222a0ee1ddc5018bd480a5a71922&"
    },
    {
      "name": "ポッピンハートバズリウムミント",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263459637663891496/IMG_1128.jpg?ex=68f5763b&is=68f424bb&hm=27fa3c91a2a82a1a85551f0ab2f11af55bf8d110e9f693b156c21d4a9cb0a579&"
    },
    {
      "name": "ポッピンハートバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263459613433532476/IMG_1027.jpg?ex=68f57635&is=68f424b5&hm=9b9a6202f1d0ebed630de6c10e3f13a2c74daa057bb653c1db5fca0e1627487e&"
    },
    {
      "name": "ドーナツパティシエールオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458804574589049/IMG_0729.jpg?ex=68f57574&is=68f423f4&hm=3ebf5a6816c2a0bad16ae5307f6fb895bddccb06f44908f899d9c08e41905c5b&"
    },
    {
      "name": "ハッピーチアライトグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458487170629703/101_20240421210703.png?ex=68f57529&is=68f423a9&hm=55fb9bfc3d183e82bc1eab8684aff38453c654e8e6915bdfdc91185d70971bea&"
    },
    {
      "name": "ウェルカムチェリー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458420481196032/101_20240421210739.png?ex=68f57519&is=68f42399&hm=2381bf522ae73be904e2a7f4a90f8cba71512fccfc2f6f5c0d7ebb048acd4a48&"
    },
    {
      "name": "ドーナツパティシエール",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458386939351113/101_20240421210744.png?ex=68f57511&is=68f42391&hm=9d82b96e66d3408c96903c37b84a62524b7f7d81b561fcb7408b90aca5365e0c&"
    },
    {
      "name": "アイプリバースポッピンハートグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458120961757235/IMG_0531.jpg?ex=68f574d1&is=68f42351&hm=b32eff0590178f30f03335ffa4302366b43681d685ade36e2af162e033b9bb3f&"
    },
    {
      "name": "ラブリーアイドルホワイトパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263458077253042176/IMG_0527.jpg?ex=68f574c7&is=68f42347&hm=bfc0eabdfd0f237f0563b9fdd5d7495d049298b4e6c7db9bdf0041f0c1dc16a7&"
    },
    {
      "name": "フラワーチュールミント",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263457800256749649/IMG_6448.jpg?ex=68f57485&is=68f42305&hm=94501f0304de410e0b59b7f442553393171eef8044abd9e620c96bccc0e7e465&"
    },
    {
      "name": "スプリングブロッサム",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263457652441219164/IMG_6470.jpg?ex=68f57462&is=68f422e2&hm=b09bf388aeb33a74f12c3af37d2686b6bd16b0943c7df7d8a135956080bec7cf&"
    },
    {
      "name": "フラワーチュールスカーレット",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263457230246641684/IMG_6433.jpg?ex=68f573fd&is=68f4227d&hm=198735b10142f45686145dd567405d76a28057b8df71cd88acd60ca93a1dc4cc&"
    },
    {
      "name": "ラブリーアイドルホワイトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263457035975131187/IMG_6431.jpg?ex=68f573cf&is=68f4224f&hm=e2e91a57b8fab7c1ab6fccc1c4aed8db9e525057f79cbbcfc9770ea93d19dbc1&"
    },
    {
      "name": "キューティーラビットレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263456168945254401/IMG_6425.jpg?ex=68f57300&is=68f42180&hm=9cf7d8c0f474be0e4da0e31455e2e9dffb445a80c7faff13478f82187670ad2c&"
    },
    {
      "name": "ウェルカムチェリーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454348512333834/1263455867550957710/IMG_6422.jpg?ex=68f572b8&is=68f42138&hm=a485bb7208af2c50d06d53492f5e980c16f5f389abe85247e9ddbcf66a01f7db&"
    },
    {
      "name": "ミラクルムーンバズリウム１５しゅうねん",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1421729430824292412/IMG_8942.jpg?ex=68f51ef6&is=68f3cd76&hm=a8b763a888eda527c44820f1086fb30bfce45af3bb08645ebf5c25a5dcef0070&"
    },
    {
      "name": "アニマルバズリウムプードルブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1421726521533403176/IMG_8935.jpg?ex=68f51c41&is=68f3cac1&hm=1c762f718c8f8b4d443d4556bd3f868891a8eff3c55a76e406a8a3fb703c7761&"
    },
    {
      "name": "フルーツソーダブルーベリー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1403659440296820759/IMG_8813.jpg?ex=68f54cf9&is=68f3fb79&hm=22cd64fd33fdb9df9422e906dc0c7d2d613d78d4ee2ea05cb9211aefe5438247&"
    },
    {
      "name": "さわやかマリンパステル",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1403658499635937361/IMG_8809.jpg?ex=68f54c19&is=68f3fa99&hm=66d146d68fe177aad1090cdc7008b65365c26edd50dc46cbd719686ddfd58694&"
    },
    {
      "name": "ミルキーウェイブラックピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1403549079333503056/IMG_6849.jpg?ex=68f58ef1&is=68f43d71&hm=5e08c49f0a839d54c65479e5902507e2ff9504fe1d2c5bf4123b3f466cd191e9&"
    },
    {
      "name": "ミラクルムーンバズリウムプリねこ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1396758114405191790/IMG_8763.jpg?ex=68f53e1c&is=68f3ec9c&hm=59ee954a820c60bad915f3ba49cba4b2c307534909b195186c533565114a0ea3&"
    },
    {
      "name": "フレンドスターグランプリホワイトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1393207169201213460/IMG_8654.jpg?ex=68f58209&is=68f43089&hm=a9df29fa25d6593201026a3fd57c97a91b204dd4cc6d6e4943f4a72f368b9eab&"
    },
    {
      "name": "クロミ なかよし",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1388281626735280148/IMG_6308.jpg?ex=68f56304&is=68f41184&hm=a4763c0fedb8a7820cb8c53213e37fc27ceea475b26825706e2194cb0b484c1b&"
    },
    {
      "name": "スペースバズリウムスターズブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1383785744300118081/IMG_8545.jpg?ex=68f582a6&is=68f43126&hm=4dd504c2d5f75de90cbeb0a27a9b720c564f33b23fb8a3da6631567f7da22882&"
    },
    {
      "name": "ステンドグラスクッキー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1367045041658400768/IMG_8421.jpg?ex=68f540a8&is=68f3ef28&hm=b96a7d0f096b954219b47e55ecaf8b014b2fdcfe11dc3dd875416bae7e424de6&"
    },
    {
      "name": "ジュエルバズリウムサファイア",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1358301518083788890/IMG_8259.jpg?ex=68f5159d&is=68f3c41d&hm=f85c4b3ceffbdfbffaaac6bd1b7f649d20b68e65352a86fc7ec9ab8ced2f8fbf&"
    },
    {
      "name": "ガーリーピアノ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1357327115678122084/IMG_5591.jpg?ex=68f57ea2&is=68f42d22&hm=1e0b096acbd79d4dbb1a149b24e886e5b704114b461cc6c50ea34618bc61ea05&"
    },
    {
      "name": "ガーリーピアノピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1357326887122370691/IMG_5590.jpg?ex=68f57e6b&is=68f42ceb&hm=9dfa6c50c1b01e6f50c85a7b766eeaaeadf9d9ece0c3a49f42811586a23f06c0&"
    },
    {
      "name": "アイプリバースミラクルムーンデニム",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1357325709483446374/IMG_5587.jpg?ex=68f57d53&is=68f42bd3&hm=550e703543331bc8ace6f37ddec89a1ec089b581eff5cc75d92c66470fd2b3a2&"
    },
    {
      "name": "スターカウガールブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1357324086157508790/IMG_5584.jpg?ex=68f57bd0&is=68f42a50&hm=a653aac50f9c5af84d2ceea0bf55192540d0de75b5079afdfdaaabcbc417eaf1&"
    },
    {
      "name": "ぷるるんゼリーミルク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1343114560944738336/IMG_8001.jpg?ex=68f534a9&is=68f3e329&hm=dd4463992fd58b2db1348e109afcfc54cbe642e45f82e77dc360669c8208b123&"
    },
    {
      "name": "スペシャルクリスマスホワイト",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1337762276899426377/IMG_7936.jpg?ex=68f58275&is=68f430f5&hm=45da6d122d1f3841ea342454c6edc600a835403b73f497ead500f168b9a28806&"
    },
    {
      "name": "ミラクルハロウィンブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1305062402030567429/IMG_7614.jpg?ex=68f53353&is=68f3e1d3&hm=782a83ea523e255a606aec3a01844cb8cbc389c2f601c3ac917b2f7aae466679&"
    },
    {
      "name": "ピチッとクロT",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1304946454569287845/IMG_3730.jpg?ex=68f57017&is=68f41e97&hm=f196f989ffffd164246449bf0728fee389a984b904794dcd3f8f9fe261105766&"
    },
    {
      "name": "クラシックバイオレット",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1304946407144427580/IMG_3729.jpg?ex=68f5700c&is=68f41e8c&hm=3c046bcffafdd79bfa3c4a27b72e4713dfad20028e0254c68f546c3a2ae5f29b&"
    },
    {
      "name": "ミラクルムーンバズリウムピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1304945180507635732/IMG_3726.jpg?ex=68f56ee7&is=68f41d67&hm=b5bf10c45ddf673e89e34abb01ecbca20f673e04e4632639908033b8df5ba7f2&"
    },
    {
      "name": "ミルキーウェイオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1294895746662797353/IMG_3335.jpg?ex=68f520e4&is=68f3cf64&hm=cdabeeeb2253bb35c44a108f2d2ff6ec2b15781768d2e81b5bdf5d1b3f845fd1&"
    },
    {
      "name": "ハッピーバースデー！みつき",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1289209121731645542/IMG_7426.jpg?ex=68f588ce&is=68f4374e&hm=8ae8c9a4e08ea5371b4320d62c3baca6cf11e50932dec98473d9bcb13e306b5e&"
    },
    {
      "name": "ミルキーウェイ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1289208622521385023/IMG_7422.jpg?ex=68f58857&is=68f436d7&hm=4f55f361b95631e2c8bd9ffc2c44fa9e3eb2f6b62da0a737b852cf14f8448227&"
    },
    {
      "name": "マジシャンキャットピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1282321915238944850/IMG_2983.jpg?ex=68f58718&is=68f43598&hm=11e0403bca84cb5eb5c0ce3a6f9ace78f13fafb54a35cc060a2cbf0a585b4727&"
    },
    {
      "name": "リトルツインスターズパーティーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1282318922888122449/IMG_7357.jpg?ex=68f5844f&is=68f432cf&hm=6b265eedf77b4d7b13eb0fec23d8693cf778d488db417eefaf5da5b9ae1b4329&"
    },
    {
      "name": "マーメイドプリンセスブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1282318794143957095/IMG_7355.jpg?ex=68f58430&is=68f432b0&hm=7ef632697e46057de9edc2ea3069936657b554796b7b373c4b8dc9d2e2a6dd13&"
    },
    {
      "name": "にゃんにゃんロリータ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1273981774099251282/IMG_7261.jpg?ex=68f5823c&is=68f430bc&hm=33903724b29a789cc05c4872a7256c267ca4411cb015193b31e14a74988bd7fb&"
    },
    {
      "name": "クールアイドルオレンジブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1269171286999826432/IMG_7224.jpg?ex=68f5259e&is=68f3d41e&hm=39d4b06894d6fc570e0c261cb34bd9ced8b093cde0c6b65dfe6238f9b3ea317a&"
    },
    {
      "name": "シークレットフレンズ∞バズリウムブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1269165992614039655/IMG_7208.jpg?ex=68f520b0&is=68f3cf30&hm=41f06e20090176135a5d89013b55aa7be376395d24ba7c9adfea7223f27014e5&"
    },
    {
      "name": "セーラーカジュアルエメラルド",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1268912522157621320/IMG_2627.jpg?ex=68f58620&is=68f434a0&hm=4bedbe741ad1579fd6bf50445930dee882384ffb00cb4231bf5a6143c98a0e5e&"
    },
    {
      "name": "ぷるるんゼリーグレープ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263468369340928020/IMG_2374.jpg?ex=68f57e5d&is=68f42cdd&hm=8ec3b55891927f68da685b87730870d15028d9bcd7d940d9fc686d9398734153&"
    },
    {
      "name": "マジシャンキャット",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263461558621831220/IMG_7095.jpg?ex=68f57805&is=68f42685&hm=30e6e206a3f496a42306e2265a467153d5ac1dea5f9f83c12d5ccd54148ed00a&"
    },
    {
      "name": "フレッシュレモンブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263461325447757886/IMG_7088.jpg?ex=68f577cd&is=68f4264d&hm=683eb5b22e1f7d9822a11818d3eed841b025b89180b5bee00858d204300005f6&"
    },
    {
      "name": "セーラーカジュアルラブリーパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263461067443671101/IMG_1486.jpg?ex=68f57790&is=68f42610&hm=d91a63891ba3fbb7a77a9e115460f91b94735a6f60892af41a3287956b6c71ec&"
    },
    {
      "name": "クールコスメ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263460298589732874/IMG_6866.jpg?ex=68f576d9&is=68f42559&hm=45f54f1e581d36dc502f86eafd87e52511ce39c910f07a5f4a2f839bbe8c6b83&"
    },
    {
      "name": "ブルージュエル",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263460269049253898/IMG_6867.jpg?ex=68f576d2&is=68f42552&hm=fdcb4f131d4b67809542aeadf14a1c88f34ffe46ac1f8fa1dd7279e80156c225&"
    },
    {
      "name": "アイプリバースミラクルムーン",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263459419367411742/IMG_6576.jpg?ex=68f57607&is=68f42487&hm=0644fc0d7ffc6861bccb76a9d238caff8ba3e116dc8322c6cefba2668a134a57&"
    },
    {
      "name": "ぷるるんゼリーソーダ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263459393874169926/IMG_6575.jpg?ex=68f57601&is=68f42481&hm=5ac302fb08d0ef3aeae178f72f64a6b6301a398bdb60b614b0d687b8bec3b0a9&"
    },
    {
      "name": "きらきらくらげブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263459350660513792/IMG_6573.jpg?ex=68f575f7&is=68f42477&hm=070d6e236cd6f84d287a0520ff645b3845b3374838374c89c977442322699e54&"
    },
    {
      "name": "ミラクルムーンバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263459324324352072/IMG_6574.jpg?ex=68f575f0&is=68f42470&hm=600c907c14d81b47a6c6c5dee9a89f88678ef436fa4f9075021c1d81a014bb1c&"
    },
    {
      "name": "きらきらくらげピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263458160954576966/IMG_0534.jpg?ex=68f574db&is=68f4235b&hm=a3a00624ea98e3bead70ed591cf63d4b6f572b2919fb44c347560cbc52d80bac&"
    },
    {
      "name": "スターメロディ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263457835262414878/IMG_6447.jpg?ex=68f5748d&is=68f4230d&hm=125f6b58102f531717d1aae52497deccfdd5a6b5986ffcc016cce419b81c3c59&"
    },
    {
      "name": "ハニービービビッドピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263457521436463155/IMG_6436.jpg?ex=68f57443&is=68f422c3&hm=1b21f2a3ce7b6b535fb37b3a99b49be63dbf550d79d8c526cd3a55900edb14a8&"
    },
    {
      "name": "スターメロディマジカル",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263457120922374186/IMG_6432.jpg?ex=68f573e3&is=68f42263&hm=de79d91e08661b0584b737a7e8f70899f65bf6ebc51428809ce824d3a8b1b430&"
    },
    {
      "name": "スプリングブルーバタフライ",
      "url": "https://cdn.discordapp.com/attachments/1263454391873175655/1263456935072497685/IMG_6430.jpg?ex=68f573b7&is=68f42237&hm=6d88222a6532c1d918f460986cf5531a805cdd0e67e1adc819966d8fc1e47f9b&"
    },
    {
      "name": "ダークカルテットスターバズリウムホワイトレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1421726371700281344/IMG_8936.jpg?ex=68f51c1d&is=68f3ca9d&hm=cfc4542ad1cc17943eeb08a59fd8523b1f851a2cbfe2e3617eac6c4f374a309d&"
    },
    {
      "name": "たいようさんさんイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1403659159492231298/IMG_8812.jpg?ex=68f54cb6&is=68f3fb36&hm=a9ee67d435ad4b102b0014fa086d9d217921e90c41a1f8df8bc879b6fb69d1c1&"
    },
    {
      "name": "アイプリバーススカーレットバタフライラブピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1396821459619287121/IMG_6644.jpg?ex=68f5791b&is=68f4279b&hm=27ec0c798d2a040daddf194adfb05e04fa48a7679dcf6f3f476a9b3d227b4351&"
    },
    {
      "name": "ゴージャスビジューレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1396754563893170249/IMG_6630.jpg?ex=68f53ace&is=68f3e94e&hm=7f1399afe0424f31ec51387f9d703640237e11fd3e00eb67c9b0959da5d4f54e&"
    },
    {
      "name": "リッチベリータルトミント",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1396120566007726090/IMG_6615.jpg?ex=68f58f59&is=68f43dd9&hm=f99ea7795bed7adca8d5825f39e04baad0e21bd024cde3dc9f5cebb00342d31a&"
    },
    {
      "name": "カルテットスターバズリウムハートローズ",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1376168706878734509/IMG_8497.jpg?ex=68f57c3b&is=68f42abb&hm=69cf679c8dee034cfe88b795daf022b88268582fab83812833433c87dd977adc&"
    },
    {
      "name": "ファンタジースノーナイト",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1367048969280159804/IMG_8423.jpg?ex=68f54450&is=68f3f2d0&hm=440e631c493da8fa93f4d864a6da9247e11af74d073dda5fd9bc3842ffd9b9b2&"
    },
    {
      "name": "ハローキティパーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1367043494891487252/IMG_8410.jpg?ex=68f53f37&is=68f3edb7&hm=375b0e6457b4f26e41795c6275310638534e2f3c2be4f9446ee0b61b052f4f9b&"
    },
    {
      "name": "ロマンスルージュ",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1367030727031525406/IMG_8393.jpg?ex=68f53353&is=68f3e1d3&hm=424d8f583ecb8929e87885ac103525b787f8db3622a8288c6068cd882a78ed11&"
    },
    {
      "name": "ファンタジースノー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343481415068815481/IMG_5127.jpg?ex=68f538d2&is=68f3e752&hm=bf4862696198a5b705fe41dfc79b2b4fb8100cf7590545c290bbae0e0c76136a&"
    },
    {
      "name": "ダークカルテットスターバズリウムレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343480941019926539/IMG_5125.jpg?ex=68f53861&is=68f3e6e1&hm=4c40c8f3e7b87491b1b461aeed2d7de6d62f8a4d7369ab55a85dfa93343e2a44&"
    },
    {
      "name": "チェックメイトシルバー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343115370109734942/IMG_7997.jpg?ex=68f5356a&is=68f3e3ea&hm=64876443d281b3f45fec3e06a475c305ed6eea79c0f1b3820e636c55483c144c&"
    },
    {
      "name": "たいようさんさん",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343115271422087228/IMG_7993.jpg?ex=68f53552&is=68f3e3d2&hm=98d122b3ff577086db002864ab20da889e96d016b42f705cecb8a258608998c8&"
    },
    {
      "name": "フェザーグランプリクールレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343114799273218099/IMG_8002.jpg?ex=68f534e2&is=68f3e362&hm=c77f3a6302b4b914c2cf731f02a06582c1bdd54353ee1d2c0dd89da0b66ece6d&"
    },
    {
      "name": "スペシャルクリスマスレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1343114754494824482/IMG_8007.jpg?ex=68f534d7&is=68f3e357&hm=829db9bc163f04c9d9a48ad3eadee4fedc208edef9cde552368021543f86a7a3&"
    },
    {
      "name": "フェザーグランプリクールピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1313112783235055616/IMG_3984.jpg?ex=68f57bd3&is=68f42a53&hm=e2e3f6feaa9b678531790e0269829816a0d1d8f65762de3d7fa7a2b8259a39c7&"
    },
    {
      "name": "カルテットスターバズリウムハート",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1296440843615473734/IMG_7483.jpg?ex=68f579df&is=68f4285f&hm=3473b7909991a2333b3c775cb0b1ad1dcc9faece104206dadc468a860f3d1ea2&"
    },
    {
      "name": "ゴーストハロウィン",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1296440794038669353/IMG_7484.jpg?ex=68f579d4&is=68f42854&hm=f61daa1065cbbdbd8fda20e2c83d7089462bedb6e24f651d9aee878a539a07e2&"
    },
    {
      "name": "ゴーストハロウィングリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1294895576160403498/IMG_3374.jpg?ex=68f520bb&is=68f3cf3b&hm=941a70e3bff3bec3108f5f222c33a2b2ae0a50d67b1f1c3aef0bff0bec17f530&"
    },
    {
      "name": "かれいなるきんぎょブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1282318752272089240/IMG_7352.jpg?ex=68f58426&is=68f432a6&hm=cbd4509951c1f7eed80e67a2ee136e2acb744fb3674ccd168fa5222eb3fba18c&"
    },
    {
      "name": "かれいなるきんぎょ",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1273998837534556232/IMG_7269.jpg?ex=68f4e960&is=68f397e0&hm=c702f647a91756c5fe7222a1515fa5d394a139d94258e5f75db0778bb6cfa845&"
    },
    {
      "name": "バタフライマジック",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1269167112954314903/IMG_7214.jpg?ex=68f521bb&is=68f3d03b&hm=e82e366928f43335f381c34f34ebb237b7c591a78ff52384b1d6a462e17bf21a&"
    },
    {
      "name": "アイスブラウニークレープ",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1269166132145684480/IMG_7210.jpg?ex=68f520d1&is=68f3cf51&hm=bd77fa592fb1772a68e0d08896461d5bfbdf8593218ddb40f1988d26d0a13d21&"
    },
    {
      "name": "エレガントジュエルレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1264567674810400818/101_20240721212226.png?ex=68f589ac&is=68f4382c&hm=eb114e51204236095e11c9695fb5cc1044a1dc9b439e43c6f014ab78e2168ef7&"
    },
    {
      "name": "ローズグランプリノーブルブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1264555324057063515/IMG_7178.jpg?ex=68f57e2b&is=68f42cab&hm=f06c705330f5bc3162976537a5d6d5c604bb02c0ca15d02e32e995c99cb314f1&"
    },
    {
      "name": "チェックメイト",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263473286856052736/IMG_7127.jpg?ex=68f582f1&is=68f43171&hm=060a68b6e39e81fd227fae3a52aa967c997917676fddf65729944c2c1bba808d&"
    },
    {
      "name": "リッチベリータルト",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263473137413263420/IMG_7124.jpg?ex=68f582ce&is=68f4314e&hm=d54e76a3922a0c2ae72e6ce5d06e5ba65c46f70060eb540269cbc52090b20a98&"
    },
    {
      "name": "ローズグランプリ",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263461389616545842/IMG_7089.jpg?ex=68f577dd&is=68f4265d&hm=bf33ad5369b0a454bc80c89ca2b8309d4ba495f2cd1f22c85e5eab91ebb175fe&"
    },
    {
      "name": "リッチベリータルトピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263460976397652009/IMG_1485.jpg?ex=68f5777a&is=68f425fa&hm=1977374a6111711e52f0a742e93be19be5075acd4a046c730e469692fa91bee2&"
    },
    {
      "name": "バタフライマジッククリムゾン",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263459715946516561/IMG_1127.jpg?ex=68f5764e&is=68f424ce&hm=af533e91c654cabfea1aaf34b879b14e19518acf9e72dcfc1c997bff4f08765b&"
    },
    {
      "name": "スカーレットバタフライバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263459278564360255/IMG_6529.jpg?ex=68f575e5&is=68f42465&hm=e68baeddaba3775bef64211f32aca70bf2a3062ae4aef6028ab79c29860926c4&"
    },
    {
      "name": "ゴージャスビジューモスグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263458987140055072/IMG_0728.jpg?ex=68f575a0&is=68f42420&hm=209cc0973e86896f10bfe6411680dfa0182363ed5aa3e4309aadb549658778d0&"
    },
    {
      "name": "クールアイドルパープルブラック",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263457452771250226/IMG_6435.jpg?ex=68f57432&is=68f422b2&hm=a03f1c1ae10d743c0d45d6d9b2441af447ed57a858f3d4be0a31d673f0bd0a76&"
    },
    {
      "name": "バタフライマジックブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454431022809088/1263457304766972064/IMG_6434.jpg?ex=68f5740f&is=68f4228f&hm=d379ff43076d083a545b16f2b7059068fa3bb9d5d90bf7fcc693e0a49c2a3f16&"
    },
    {
      "name": "ダークカルテットスターバズリウムホワイトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1421726347620782090/IMG_8938.jpg?ex=68f51c17&is=68f3ca97&hm=9b5dd76b530057e5aee7c480e8c0f43644e5058f3865d5451dc4d513cacfdff3&"
    },
    {
      "name": "ローズグランプリピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1396754675537150082/IMG_6632.jpg?ex=68f53ae9&is=68f3e969&hm=cb9110cf618b02cd3e9c113c2cf7dfb19a6cf96105c13df964acd127e4afadb2&"
    },
    {
      "name": "カルテットスターバズリウムスペードスカーレット",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1357685281104593057/IMG_8250.jpg?ex=68f57ab3&is=68f42933&hm=b0b8b838ff255126fa2ebea7d1fed907dace82fcd3ce21297b6b1a58e554dd83&"
    },
    {
      "name": "ダークカルテットスターバズリウムブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1343485283156492350/IMG_5133.jpg?ex=68f53c6c&is=68f3eaec&hm=0477db275b3570cfe6f1905445d33561a96930a6043372a8fdf6f1667c918ee7&"
    },
    {
      "name": "フェザーグランプリクールブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1343115164593160292/IMG_8003.jpg?ex=68f53539&is=68f3e3b9&hm=58cccaa3254afe062a39703d36f60a94bb360e1b7b0e61da912a5b5e4a37fb9f&"
    },
    {
      "name": "スペシャルクリスマスブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1343115101192065035/IMG_8006.jpg?ex=68f53529&is=68f3e3a9&hm=d5273e42f3c3e56ce2d59005a659baefe09bdbd9cb4fab48bf955f587d33a55d&"
    },
    {
      "name": "カルテットスターバズリウムスペード",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1297420516864295012/IMG_3483.jpg?ex=68f515c4&is=68f3c444&hm=dd42de6f4f2b322daca9e028dad7bdd691ec22198d48c15470ac7d828b843d83&"
    },
    {
      "name": "ひらめきたんていクラシック",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1294895429980393533/IMG_3334.jpg?ex=68f52098&is=68f3cf18&hm=44d1c1184923d7d14b1666053fd190abe2fd46edf4f3b4776da2433abc1ec3e1&"
    },
    {
      "name": "シナモロールパーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1289209253990629386/IMG_7423.jpg?ex=68f588ee&is=68f4376e&hm=7b29e464342bf9c67e6ac78725d6e8c18690c2ac4664b1db6c4d65eee3c633e6&"
    },
    {
      "name": "アイプリーバースロゼッション",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1289208772899901461/IMG_7424.jpg?ex=68f5887b&is=68f436fb&hm=fb64e3f549a430c46bec93a15d2f009d5bb2a700144d51c8c5bb3e3dfdca7ece&"
    },
    {
      "name": "ローズプリンスライトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1282318670814777354/IMG_7350.jpg?ex=68f58413&is=68f43293&hm=01b0110d97f62a1348b43ccef4ff0dacb3c3ac47fc8acbaaa4621c7fef724843&"
    },
    {
      "name": "ゴシックマリン",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1273981987774009405/IMG_7264.jpg?ex=68f5826f&is=68f430ef&hm=cf94285ecbf89bbda023d6d43a732ff7c48143618c43963bc88530c449f7f55b&"
    },
    {
      "name": "ローズプリンスシック",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1273981959244091432/IMG_7263.jpg?ex=68f58268&is=68f430e8&hm=a4dab1335270e340eaf1d69ec662dcc4e6bbb9060ff0473a65b76b545075b42f&"
    },
    {
      "name": "エレガントジュエルブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1268911379566297171/IMG_7200.jpg?ex=68f58510&is=68f43390&hm=b09cf915978fa2e8a86e7a368c896f8052041afdd34163a1157120f6fd099f8d&"
    },
    {
      "name": "クールアイドルナチュラル",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1264125948379271220/IMG_2410.jpg?ex=68f53fc8&is=68f3ee48&hm=32d9a75cf43c067f33184d981141efc3a1149045a50f7f0c8c67b18ed2a5fa33&"
    },
    {
      "name": "アイプリバースロゼッショングリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1264125710113443911/IMG_2409.jpg?ex=68f53f8f&is=68f3ee0f&hm=1c833f919d384b94590ec3d24f618a2f90e42a54a715c59cc5e996ba0a58c1c9&"
    },
    {
      "name": "ロマンスシャンデリアピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1263473166790037544/IMG_7131.jpg?ex=68f582d5&is=68f43155&hm=af0cf1bceec56d3aa0b40ecde2373ad7d7b9f2e0556c41966c28f8a429ebb370&"
    },
    {
      "name": "ロマンスシャンデリア",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1263469267496730754/IMG_2377.jpg?ex=68f57f33&is=68f42db3&hm=81ffa8ced96ad33ca782a6d9cfc6e56bb82a296c2729246c4cbc024700917244&"
    },
    {
      "name": "ロゼッションバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454457874743367/1263460529813585952/IMG_6862.jpg?ex=68f57710&is=68f42590&hm=5d08d1ba56fd09970fef44d0c11f4a792a99d2b7225a5000edce69e57dcb0579&"
    },
    {
      "name": "フラワーガーデンピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1428988288475074652/IMG_7444.jpg?ex=68f5294d&is=68f3d7cd&hm=297b1a7ae1b23c5d1614719188219435021cde7ec7b935b03104005b27ddab6e&"
    },
    {
      "name": "フラワーバズリウムクローバー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1428988233060061234/IMG_7442.jpg?ex=68f52940&is=68f3d7c0&hm=9aa479ba006e506daa98489e835f269f12707856f915d67179560649c147cc09&"
    },
    {
      "name": "フラワーガーデンブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1421730024993853460/IMG_8933.jpg?ex=68f51f84&is=68f3ce04&hm=ee180473929986384367133fb4ddb74dd706aef67edf47c25ec57107e30d1954&"
    },
    {
      "name": "フラワーガーデン",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1406088349365829722/IMG_6930.jpg?ex=68f59152&is=68f43fd2&hm=b187552ff7c78b89b572a65a90c513702f26c14a61bb71a37e09e0eb32e51e76&"
    },
    {
      "name": "アニマルバズリウムプードルイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1405682584159129811/IMG_6910.jpg?ex=68f568ec&is=68f4176c&hm=ecc3e1038bbaa0061a9c53347d0f66ac9c1bd8fd43f4e22b3246eeddd95aa074&"
    },
    {
      "name": "ひまわりサマークール",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1403658842125897810/IMG_8810.jpg?ex=68f54c6a&is=68f3faea&hm=416eb6577068f4ada4fa9902e721de9f12ed7fceb0f7b255367afb2430ac23ae&"
    },
    {
      "name": "アイプリバースフラワーマーチプリンセス",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1396756659120111676/IMG_8415.jpg?ex=68f53cc2&is=68f3eb42&hm=ee4a0f3afce480beecfcfbf5c8740b2d3d02b73cef4820f32ef41b020363f090&"
    },
    {
      "name": "リカちゃんフラワードレス",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1396756400876687440/IMG_6638.jpg?ex=68f53c84&is=68f3eb04&hm=086ebba3466afe6f3f5e742901b28644b5a1c0a29886183db41a07964c920af0&"
    },
    {
      "name": "フラワーマーチプリンセスバズリウムピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1388280813753335828/IMG_6306.jpg?ex=68f56243&is=68f410c3&hm=fbb978f6f8df11c82f6a0e1fc9720a742d011b8bd3f7d610d470526ec01abbdb&"
    },
    {
      "name": "こぎみゅん なかよし",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1382583098688143442/IMG_6224.jpg?ex=68f51719&is=68f3c599&hm=60ee01d16686c8ebe7dbe76169ee0e787c3aca67238282588ec0483651ff2b85&"
    },
    {
      "name": "きらきらくらげピュアホワイト",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1373484365878792202/IMG_6070.jpg?ex=68f4f2be&is=68f3a13e&hm=8149486abe10ee4103bd44f3869b629320a792c80f9c6c5154783900b23f94d7&"
    },
    {
      "name": "おしょうがつイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1367032254391390218/IMG_8401.jpg?ex=68f534bf&is=68f3e33f&hm=ebc6d5b029388628556b9114c50155131dbf159c37d98f7692e5ec617c6ae029&"
    },
    {
      "name": "バレンタインレターイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1367031922705825802/IMG_8400.jpg?ex=68f53470&is=68f3e2f0&hm=e107cfb0dfef229551305b4e90e1bb55fa1a481fc613abf7a54aee9453808022&"
    },
    {
      "name": "フラワーメモリーピュアホワイト",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1367031808830738432/IMG_8399.jpg?ex=68f53455&is=68f3e2d5&hm=1e3f7451622c0f1a26b2ee97dd5a6574da1b1e8d826353da3c5c5f25bac15ec9&"
    },
    {
      "name": "フラワーマーチバズリウムパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1367031295863164928/IMG_8396.jpg?ex=68f533db&is=68f3e25b&hm=0f75e801c07c00bcb507f49a0329b5701b1d12bae4f7be752d299fbf623ec06f&"
    },
    {
      "name": "フラワーマーチプリンセスバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1363393789858939011/IMG_5850.jpg?ex=68f5272a&is=68f3d5aa&hm=3034c20cb2d3f26aae7f7f5720c036ff4d1b5def6be8bf3414f94fb8ed169e42&"
    },
    {
      "name": "つむぎのアイムゥ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1343481631469469728/IMG_5128.jpg?ex=68f53905&is=68f3e785&hm=4ea2c6644782e95ce21c171781bb4803ba7b641bd3ef05c3490ca7484e0a21ec&"
    },
    {
      "name": "オーロラスノーグランプリ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1343480724799623199/IMG_5124.jpg?ex=68f5382d&is=68f3e6ad&hm=efe7914e51ae2c60ca76e6ff7b634690c6ebc546d36fe8bb025e650892108845&"
    },
    {
      "name": "オーロラスノーグランプリライラック",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1343115584396591246/IMG_7996.jpg?ex=68f5359d&is=68f3e41d&hm=ea7ea42021b8867bb862e15509aaf209e43855b771112bb7aee4e4b682426b0b&"
    },
    {
      "name": "フラワーマーチプリンセスバズリウムブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1337762117951950889/IMG_7935.jpg?ex=68f5824f&is=68f430cf&hm=26f0547b8740a8104ee0d2c989171ea438c8d5b1e20bec8d4a5683cdaaf534d1&"
    },
    {
      "name": "ハッピーバースデー！つむぎ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1337393712099102841/IMG_4818.jpg?ex=68f57cb4&is=68f42b34&hm=dd59e85cc403691ee86acaf6e095c66e87396f68432bd51687f265b1dd6e6bb6&"
    },
    {
      "name": "ギンガムチェックレモン",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1313112707364556811/IMG_3985.jpg?ex=68f57bc1&is=68f42a41&hm=d45a6090ad9a2754a0b440d5dd6b4155fff1c250b600b85c8b0421666feca8f8&"
    },
    {
      "name": "ネイルポリッシュナチュラル",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1313112661130481715/IMG_3983.jpg?ex=68f57bb6&is=68f42a36&hm=ecc2ca45a56c510c2cf2485423a5c9e180e08df79ac89c2f161b9ea6d1713cb5&"
    },
    {
      "name": "ミラクルハロウィンイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1307341379931734057/IMG_3794.jpg?ex=68f4ec0a&is=68f39a8a&hm=0157f79c317e2b3f7c5a637ed2c909e76f6d7cc8863c89deb786a6ce6496d9e9&"
    },
    {
      "name": "ハーバリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1307339619540664382/IMG_3790.jpg?ex=68f4ea66&is=68f398e6&hm=f2d2a159cd9eccc46bd8003fbf6ea9a84afc324789286138e9efbc3e2e87ceca&"
    },
    {
      "name": "パッションコスメ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1294895338439839754/IMG_3332.jpg?ex=68f52082&is=68f3cf02&hm=47e1b7abb4cc45a34d9ec93bcff1b64c224542ee9568283e556a9fc7eebe57cf&"
    },
    {
      "name": "リトルフェアリーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1290652231221121025/IMG_7439.jpg?ex=68f582cf&is=68f4314f&hm=88f18e2ec9dec1b60e6b2dec26e9ba0d176dfd2e4825fd7296bf5b6cc5603ec5&"
    },
    {
      "name": "パティシエはちみつパンケーキ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1279782492991262750/IMG_2918.jpg?ex=68f58493&is=68f43313&hm=63fe9222b7d07095af67d5b69f3c39cfada1054f773f2e32407f4859727d8bc6&"
    },
    {
      "name": "アイプリバースフラワーマーチピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1279782454223437884/IMG_2916.jpg?ex=68f5848a&is=68f4330a&hm=676072c20e96e5e104aa3674db964d22e0c477c515bdc9be948665838c4c7c47&"
    },
    {
      "name": "マーメイドグランプリイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1279782419016192101/IMG_2920.jpg?ex=68f58481&is=68f43301&hm=d788a6c360db64f8ee36cf5372c4bbaa2e844bc8930a683e95d57530f1b8b7ff&"
    },
    {
      "name": "シークレットフレンズ∞バズリウムイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1273998693921718314/IMG_7267.jpg?ex=68f591fe&is=68f4407e&hm=4a35007d9a8e305ee17a13d6b7bc7f4414868a4a9a547a2276baf7b6d0019274&"
    },
    {
      "name": "ポムポムプリン パーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1273997062287134813/IMG_2711.jpg?ex=68f59079&is=68f43ef9&hm=dc616d23e01a4008b8c206e8ae27afa33871f363bd512334689eb260525a9f04&"
    },
    {
      "name": "ことりメルヘンスカイ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1273996634639831040/IMG_2709.jpg?ex=68f59013&is=68f43e93&hm=2f02ed8870717c0626c455b95738d1e9bfdef89fd9138592deedf68ebea7f634&"
    },
    {
      "name": "わんわんロリータ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1273996223447302285/IMG_2707.jpg?ex=68f58fb1&is=68f43e31&hm=bd5c9e8b096c45ab61139f8aa29d6c4670e76e9733ec1fada640fc34b26012e6&"
    },
    {
      "name": "ぽんぽんすずらんブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1273981634340851763/IMG_7262.jpg?ex=68f5821b&is=68f4309b&hm=209bebbd4f76bb76e34e19213b9f835873b929b05f028d6a7ea39538d825e280&"
    },
    {
      "name": "リトルフェアリー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264568257197637693/101_20240721214304.png?ex=68f58a37&is=68f438b7&hm=1dfe19eeff172cd025e203d29423218e748f3d0d62e203e9da6f4236f75b563a&"
    },
    {
      "name": "ことりメルヘンナイト",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264125540864884736/IMG_2408.jpg?ex=68f53f67&is=68f3ede7&hm=01903dcb91f1952a4d600470de2fb9ce152a2e3d6e8d1c2965d7d0f4419e802c&"
    },
    {
      "name": "クローバーメロディ",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264125355766321182/IMG_2407.jpg?ex=68f53f3b&is=68f3edbb&hm=aaae69e9ca9d0ec04f968033b8a58205f690e836ba03f486ebd6edc955508edb&"
    },
    {
      "name": "ぽんぽんすずらんピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264122538259124234/IMG_2406.jpg?ex=68f53c9b&is=68f3eb1b&hm=aab69c22893b6a5b4fc59f70a4bac72a1688d0c4fcc8d97476ea58cd7f583c6d&"
    },
    {
      "name": "フラワーメモリーパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264122278359076866/IMG_2405.jpg?ex=68f53c5d&is=68f3eadd&hm=894b4b12b3f71f373085b7d7587358de564d3e1259ec3e141a302fc5297f2f0a&"
    },
    {
      "name": "フラワーメモリー",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1264122131092869191/IMG_2404.jpg?ex=68f53c3a&is=68f3eaba&hm=17ece435a09c69cf9fb1f641ade2e1178fb3d0f5b3a44755618e8c5946daa365&"
    },
    {
      "name": "リトルフェアリーグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1263475401984835637/101_20240718213949.png?ex=68f584ea&is=68f4336a&hm=265bdac73e38f9a43fd9034443ceab6772be5357d8fe276620d1bbc9620938f2&"
    },
    {
      "name": "フラワーマーチバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1263470329419010098/IMG_2382.jpg?ex=68f58030&is=68f42eb0&hm=31d8ab89d85840aa076edc4de8e510cf44a1879b23160bf667b38bf589de9629&"
    },
    {
      "name": "イエローグリーンジュエル",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1263470130399154326/IMG_2381.jpg?ex=68f58001&is=68f42e81&hm=0f25e5b8c2ef8657eb1ea1d0d3cc592a30aae429bb6fa17bbd9be46266eeae98&"
    },
    {
      "name": "アイプリバースフラワーマーチパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454489952780329/1263469873129066597/IMG_2380.jpg?ex=68f57fc3&is=68f42e43&hm=19ff5ab50e62422ecf01cc1dcc61f7d0a0ded5d3be1eae7f3a98c650e825cab9&"
    },
    {
      "name": "ダークカルテットスターバズリウムホワイトグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1421726269254533220/IMG_8939.jpg?ex=68f51c04&is=68f3ca84&hm=0779477ff94be7d331bcabbabccd0c9643196be24fd48bb816276ef5786b2b5e&"
    },
    {
      "name": "たんけんかレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1403659852277874750/IMG_8814.jpg?ex=68f54d5b&is=68f3fbdb&hm=99633f8068b9f124418cc026a27209935981d32bc98559ab1786ef637ac4ec60&"
    },
    {
      "name": "カラフルキャンディブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1403659020006457344/IMG_8811.jpg?ex=68f54c95&is=68f3fb15&hm=e94afe926233c32041e5a0357854453de56708a7c31a626bda7ff882beca9c28&"
    },
    {
      "name": "ラブリーアイドルグリーンオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1396821503760273529/IMG_6645.jpg?ex=68f57926&is=68f427a6&hm=709fed28ccc93315efeb8f0af8d503002cfe1b23192a5269be68336c3ded68a4&"
    },
    {
      "name": "カラフルキャンディハッピー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1357326426671677561/IMG_5588.jpg?ex=68f57dfe&is=68f42c7e&hm=d4a1d15cbccba97c881ceaba933e5b7d9f5aa110cb9d4603c2721e66c103588c&"
    },
    {
      "name": "ふわもこかいじゅうミルキー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1357325403332546681/IMG_5586.jpg?ex=68f57d0a&is=68f42b8a&hm=73fa3373c76bafaae37943c756974274c3cd0af193d66e7147ed2cc1749043c3&"
    },
    {
      "name": "フェザーグランプリラブリーグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1343480687944011816/IMG_5123.jpg?ex=68f53824&is=68f3e6a4&hm=13bcc788368d35167f07052caccf31d4fe6f5bae284d9698dd788e3a5165b205&"
    },
    {
      "name": "ダークカルテットスターバズリウムグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1343115721978417152/IMG_7998.jpg?ex=68f535be&is=68f3e43e&hm=8329c3dd265dced38598206bb74a0f413413d97098e7bfee009202fcf298938a&"
    },
    {
      "name": "カワイイあめちゃんポップ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1337393846828666880/IMG_4819.jpg?ex=68f57cd4&is=68f42b54&hm=fb3b04c712570c81f49e7dd107cdf4c617b1c9222d32865ce56e4ef5aaf3e007&"
    },
    {
      "name": "カワイイあめちゃんげんきオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1313493054136651797/IMG_7697.jpg?ex=68f58c7b&is=68f43afb&hm=18bd465cafdf5197d89655e96ad5b03ab2d41c35cbed5d3e6d690aa00da8950a&"
    },
    {
      "name": "ハッピーチアグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1307341239745777777/IMG_3797.jpg?ex=68f4ebe8&is=68f39a68&hm=11f45420583c93e3a91bcbfd73163bb4fa043e868ea536a7e46e9e35c608facd&"
    },
    {
      "name": "カルテットスターバズリウムダイヤ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1294893501825286144/IMG_3426.jpg?ex=68f51ecc&is=68f3cd4c&hm=8d5a6f4f9295a243a4060eaf6485f5fa7cef541044e42d9343e756b791ccd582&"
    },
    {
      "name": "ハッピーバースデー！アイリ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1294893470561079296/IMG_3425.jpg?ex=68f51ec5&is=68f3cd45&hm=0c417bb77280743cb77e47624707f0530a21a0f90950951a5c3c5320cc476f66&"
    },
    {
      "name": "トロピカルサマーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1291377525653508127/IMG_7445.jpg?ex=68f5834a&is=68f431ca&hm=1ce73a55c36b82c7ec1928fdcb1ebef0b579d243b0869f0b7be891f38ea0fa60&"
    },
    {
      "name": "アイプリバースレインボーキャンディ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1290650962330910791/IMG_7438.jpg?ex=68f581a0&is=68f43020&hm=38639ccbc48f02be0bc3f84299001cf6793402dfe6f5944fc1b3a84a498632fd&"
    },
    {
      "name": "ポチャッコ パーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1282323554930790439/IMG_2986.jpg?ex=68f5889f&is=68f4371f&hm=e6e8263dde734fcf805d4ad17c9310c21902868da3868bfe6c790f7ed33dc1f1&"
    },
    {
      "name": "カワイイあめちゃん",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1282322978121584681/IMG_2985.jpg?ex=68f58816&is=68f43696&hm=3412c5e794b95adbb0751ffdb25bbaed9ed866479c1e10ba720b1b5b509fa67b&"
    },
    {
      "name": "レインボーキャンディバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1282318771528138773/IMG_7354.jpg?ex=68f5842b&is=68f432ab&hm=549c00f283e977e05f445271e7f2aa597244ef59fab0d6a3f396d4a310e02d14&"
    },
    {
      "name": "アイスクリーム",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1280153079257239645/102_20240902220814.png?ex=68f58c36&is=68f43ab6&hm=9fbf0080412744fa860817a582ef88ffe7f6114f2f9610870f8d08e7526ba0e3&"
    },
    {
      "name": "トロピカルサマー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1280137466036093002/IMG_7332.jpg?ex=68f57dab&is=68f42c2b&hm=87f3770795c54da42ecb80137732e1ec51b561bebecf7d0d27317b08d9e5f540&"
    },
    {
      "name": "カラフルキャンディイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1279782568358576149/IMG_2917.jpg?ex=68f584a5&is=68f43325&hm=8d46cc12371ca51a1cd03de4d04fed6a0f7e63a9dd45ddced2b439da2e06f1cd&"
    },
    {
      "name": "アイスクリームオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1273998888621052027/IMG_7270.jpg?ex=68f4e96c&is=68f397ec&hm=ae815efd1d29fc5b1ea15ec18cc478533213752eb301ba17b69b3a5a6db09b27&"
    },
    {
      "name": "カラフルキャンディ",
      "url": "https://cdn.discordapp.com/attachments/1263454523494629417/1269165760375291934/IMG_7206.jpg?ex=68f52079&is=68f3cef9&hm=dd0490b7cbdca858110b68a81cd49c355f4c59c541afad21660b0be801594a3e&"
    },
    {
      "name": "ダークカルテットスターバズリウムホワイトオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1421726395519860736/IMG_8937.jpg?ex=68f51c23&is=68f3caa3&hm=6126507d8d2e9a6c3d2929dc5e44797efe82971f4dc6d0e2a2df9391a7b38395&"
    },
    {
      "name": "クラシックヴァイオリンブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1367044667375357972/IMG_8418.jpg?ex=68f5404f&is=68f3eecf&hm=0a301eae6c2a1cf76abc5d95dc1e17aa66d4c65587265f2af2fdbb2fcba2032b&"
    },
    {
      "name": "おやすみメリーナイト",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1367035919986856047/IMG_8405.jpg?ex=68f53829&is=68f3e6a9&hm=00ea7e3f6725b8f6ee1370b16d03451a6664aadcc2fe73f9a55c2820b57ae438&"
    },
    {
      "name": "カルテットスターバズリウムクラブキャンディ",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1357326684801470554/IMG_5589.jpg?ex=68f57e3b&is=68f42cbb&hm=8a8b36b4899152f23e4c4696951430149acd180cbce3f05805eb4e6169b588ce&"
    },
    {
      "name": "ティーパーティーはるかぜイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1357324430497415392/IMG_5585.jpg?ex=68f57c22&is=68f42aa2&hm=e27720c900725ca1769649d607f90609c6b37436b2c76a7767fc5396d0991629&"
    },
    {
      "name": "ダークカルテットスターバズリウムオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1343115787174674442/IMG_7999.jpg?ex=68f535cd&is=68f3e44d&hm=313b0ab1baf98db87e5cadc551029549781e0b793ee624f1c86c891debc69ad3&"
    },
    {
      "name": "フェザーグランプリラブリーオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1337393642318594088/IMG_4817.jpg?ex=68f57ca3&is=68f42b23&hm=cb95140785d5bfafc68d84ca134b336d2baebdd8c22657b25f87617dd4228e82&"
    },
    {
      "name": "カルテットスターバズリウムクラブ",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1297420586825551924/IMG_3484.jpg?ex=68f515d4&is=68f3c454&hm=2ba64bd181f66f9d8f8a6e0706b6af46ec7e24fd55a5aaec7699fdc834b35a71&"
    },
    {
      "name": "カワイイくまさん",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1291002143834112051/IMG_3337.jpg?ex=68f57730&is=68f425b0&hm=b1bdd8e0ddaaa7e87a742b2ae6116a4596dfb3ad17c0eb632cdcdc080b1e4274&"
    },
    {
      "name": "ベアベアベアバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1291001865131135006/IMG_3336.jpg?ex=68f576ee&is=68f4256e&hm=b75999ac92884193d4658e329f4f0f1a5623aa98eaa4a3b02e6e7b6cb135a293&"
    },
    {
      "name": "マイメロディパーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1291001210614321172/IMG_3333.jpg?ex=68f57652&is=68f424d2&hm=d3833f0d009fe983285ee97ebc89d143554e4be3999fbf7003298b14422b7f6e&"
    },
    {
      "name": "ハッピーバースデー！リンリン",
      "url": "https://cdn.discordapp.com/attachments/1263454645309800499/1290653747755749418/IMG_7441.jpg?ex=68f58438&is=68f432b8&hm=f7dc43934bbef5b505210aa0f9d5fdfe2a25f6189cb21adbc5229232379011b8&"
    },
    {
      "name": "アニマルロックレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1421726610457100349/IMG_8934.jpg?ex=68f51c56&is=68f3cad6&hm=32f396842000de1320bec3bcf5b6440ec83a2f85ccb3d56a5cbb0f414f291f79&"
    },
    {
      "name": "パンキッシュペンギンパステル",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1421684832337137695/IMG_7302.jpg?ex=68f4f56d&is=68f3a3ed&hm=3dea8e322af14c92ad5246735fa861dd128a2db8f83a620abce6d5cfad23a1fd&"
    },
    {
      "name": "アニマルバズリウムパンサー",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1421684729517838420/IMG_7301.jpg?ex=68f4f555&is=68f3a3d5&hm=e84f4de97f7d791bc372ddbd92a1a2b55d2c043b9f012ee5becdf11c441b2260&"
    },
    {
      "name": "アニマルバズリウムタイガー",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1421684676413886499/IMG_7300.jpg?ex=68f4f548&is=68f3a3c8&hm=29b6c72515a491d36e7f8ccd77fdf1428d7c68309e4a219060e2d20bb64f35f0&"
    },
    {
      "name": "アニマルロックブラック",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1405682247746457610/IMG_6908.jpg?ex=68f5689c&is=68f4171c&hm=5e30cdc24bb099204dea8ade5e5fc0ff5311b9e1da067fe9a4413a49da155542&"
    },
    {
      "name": "ウィッシュメロディグランプリ",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1403658243678535802/IMG_8808.jpg?ex=68f54bdc&is=68f3fa5c&hm=f611dbe17f4732cf0742181721ca7168e3b190b2868d410439d5f939d1dfd5a0&"
    },
    {
      "name": "ハンギョドン なかよし",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1388281305447399454/IMG_6307.jpg?ex=68f562b8&is=68f41138&hm=cce832e51489cb5a2b29e09941987fb85c55f9a5df502f41024a507baf9b44ce&"
    },
    {
      "name": "アイプリバースラブマイミュージックピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1367045811602722877/IMG_8422.jpg?ex=68f5415f&is=68f3efdf&hm=d00ac57b1af4237879fafd3a68a0d1fefc940c0a4446f80f0bb8d43d70eab3ff&"
    },
    {
      "name": "かみなりぐも",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1367043743370182678/IMG_8412.jpg?ex=68f53f72&is=68f3edf2&hm=fc8fc2103f44cdaa34a3170fa70bddd5bddc4090f0b4fdff590e4c5aa8f5439c&"
    },
    {
      "name": "こあくまロックイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1367031488343838801/IMG_8397.jpg?ex=68f53409&is=68f3e289&hm=bec15a174e0d175ac545a2941b84ac3526d051f682266d5691241a3cc1183640&"
    },
    {
      "name": "ラブマイミュージックバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1367031189671510086/IMG_8395.jpg?ex=68f533c1&is=68f3e241&hm=2178a7850784b8208f01a5daa0d7a13c9a895ef79437b1fa68108b8e77a79669&"
    },
    {
      "name": "ダークウィッシュメロディ",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1357684900219584572/IMG_8248.jpg?ex=68f57a58&is=68f428d8&hm=daef2f3c9a8654a9461c565c234b096626cbc84b947f96c1e6abb4a197ad2f53&"
    },
    {
      "name": "ダークウィッシュメロディモノクローム",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1357334614963912734/IMG_5594.jpg?ex=68f5859e&is=68f4341e&hm=9d1a503d37fb918f5476a6f2be609e730d5170514ade7c87bb9b0a742d71ce5c&"
    },
    {
      "name": "パンキッシュペンギンパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1357323733563605032/IMG_5583.jpg?ex=68f57b7b&is=68f429fb&hm=576a1cf2bafb31febf3d8aa5fd3b8e36650e43ed09018b68442292a2bacfa53d&"
    },
    {
      "name": "アイプリバースラブマイミュージックダーク",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1343481155323826226/IMG_5126.jpg?ex=68f53894&is=68f3e714&hm=cbcd1549c335c3a1aed07e78d956e47a1705a8c5b182828d4ba620db1b03e559&"
    },
    {
      "name": "こあくまロック",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1313492915779010591/IMG_7699.jpg?ex=68f58c5a&is=68f43ada&hm=4b69794026a4a8a52729ffda74c48856f7ff080dc34c0537145febc102de098e&"
    },
    {
      "name": "こあくまロックわたあめピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1304945314276577412/IMG_3727.jpg?ex=68f56f07&is=68f41d87&hm=3591266c619024f16a4e016caf78c4890b835aa493025fc89e90d2ca99100fff&"
    },
    {
      "name": "クロミパーティー",
      "url": "https://cdn.discordapp.com/attachments/1263454682961936386/1282323768949346314/IMG_2987.jpg?ex=68f588d2&is=68f43752&hm=5aa638609b113884a56e827a25c77d16aed904efd550d12ea97e966273f896e4&"
    },
    {
      "name": "ひみつのディアマイフューチャーみつき",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1421729360745857094/IMG_8940.jpg?ex=68f51ee6&is=68f3cd66&hm=db0ee103731fd24dc7f0e648bd6b685828cc162226d5eca0282b56c144959f39&"
    },
    {
      "name": "くまくまパーク",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1421727057171185766/IMG_8925.jpg?ex=68f51cc0&is=68f3cb40&hm=464c1b2c8bd1d1c54233c843425b3ac8c864686f2efb9b0bdbe89e81368edb8f&"
    },
    {
      "name": "タテジマなりきり",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1421727047704776704/IMG_8924.jpg?ex=68f51cbe&is=68f3cb3e&hm=9fe69b15d2e7e070c2a52e247b7bc8b8c0f372684cefe2bbcfad12a4de7af8f0&"
    },
    {
      "name": "ひみつのプリマジひまり",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1405682649250660474/IMG_6909.jpg?ex=68f568fb&is=68f4177b&hm=c0dcc94b5a960bb4af99039eb035f6230122c9de60674ffbd24e6a0ebc841f97&"
    },
    {
      "name": "ハーネスルックブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396757713974988810/IMG_8761.jpg?ex=68f53dbd&is=68f3ec3d&hm=a9a987e23429e26e9acc1de0116e671c4fff96bc532411f810fb090b1cef3539&"
    },
    {
      "name": "ハーネスルックレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396757682530291842/IMG_8760.jpg?ex=68f53db6&is=68f3ec36&hm=0eca949b57d76aa293c864618196c032bd09047628a067493dd2a6a01b8f88ab&"
    },
    {
      "name": "ギャラティックパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396757376140578906/IMG_8757.jpg?ex=68f53d6c&is=68f3ebec&hm=e415b36d7f693f1a5fdec853459852655d45212e1f1aebfb51d712437b0f3fbe&"
    },
    {
      "name": "ギャラティックブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396757233659936839/IMG_8756.jpg?ex=68f53d4a&is=68f3ebca&hm=03def516544afa55cb4f78cb1720500dd4fd3f0f152c4458ed0a1014b5a29cb1&"
    },
    {
      "name": "ギャラティックレッド",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396120863358844988/IMG_6618.jpg?ex=68f58fa0&is=68f43e20&hm=a0a8bad9e43cd8ce1c77805c62f3add56ae824dabbd2926a474d54281bc2288c&"
    },
    {
      "name": "ヒロさまコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1396120736405524603/IMG_6616.jpg?ex=68f58f82&is=68f43e02&hm=d87fd619eefa57271cdd71ead26af1ffef1e871ae1668862de0a61d468041b29&"
    },
    {
      "name": "ひみつのプリ☆チャンえも",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1373488985527287918/IMG_6071.jpg?ex=68f4f70c&is=68f3a58c&hm=38c6c58400d60fef9d272d2695ba9c284f7b3e588d9f351f217be3bda3ed68b1&"
    },
    {
      "name": "プリズミー☆サンシャイン",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367038585831690251/IMG_8409.jpg?ex=68f53aa5&is=68f3e925&hm=ef3907f14f3eefec58a34567e3cae8933187189f84c17927671b68c89f1c6191&"
    },
    {
      "name": "サマーメイドブラックベリー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367038488196812851/IMG_8408.jpg?ex=68f53a8d&is=68f3e90d&hm=f9a94b061919fad1a8b23bce178fd95c7aea245fc80d871f9eda384431527984&"
    },
    {
      "name": "ゴシツクフリルナイトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367038426741866526/IMG_8407.jpg?ex=68f53a7f&is=68f3e8ff&hm=1f3cd0c3c0aa91fc5ec2498495583888e5449f54eb80ffb33450f619b6b86052&"
    },
    {
      "name": "フラワーショップフリージア",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367038366402482196/IMG_8406.jpg?ex=68f53a70&is=68f3e8f0&hm=23a751e305882ba1b6792bfd0f26c75b8d1d9ed1e2c65a12fbf42f4c5a62d708&"
    },
    {
      "name": "はばたきのシンフォニア",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367036371620855860/IMG_8402.jpg?ex=68f53895&is=68f3e715&hm=24169d8bbbebc37e4fbea4620c4fc079af8afa9ae3531a0eebbb039b0aa6ef46&"
    },
    {
      "name": "プリズミー☆シャイニースター",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367036279031857163/IMG_8403.jpg?ex=68f5387f&is=68f3e6ff&hm=5ea7f6a478dfea0cbf31f6382f5f2372705d66a016eb2402add19ba5b5ece308&"
    },
    {
      "name": "セブンスコーデポップ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1367036031198695485/IMG_8404.jpg?ex=68f53844&is=68f3e6c4&hm=4288f96a63bddee277767d87b525f572e20e43fcb27dc1fc4432759e115a0726&"
    },
    {
      "name": "ひみつのディアマイフューチャーかりん",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1360951628244455545/IMG_8302.jpg?ex=68f57f39&is=68f42db9&hm=c4a90d200550ec06c2e4412884f4cc313ede5a646adc0ead9f6209ba623fcd94&"
    },
    {
      "name": "じょうねつのシンフォニア",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1360951441522692107/IMG_8301.jpg?ex=68f57f0c&is=68f42d8c&hm=361e535b3e56da686e0210f2f9d29a74bfeda56fc6a299c175716012afd7073b&"
    },
    {
      "name": "セブンスコーデラブリー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1360939801586438254/IMG_5782.jpg?ex=68f57435&is=68f422b5&hm=09a6cbba647395ae2d6e0350f27c786ee5b0df531ae8f7e1343bb06024df7769&"
    },
    {
      "name": "チャイナネオン",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1357334365973250198/IMG_5593.jpg?ex=68f58562&is=68f433e2&hm=db6a00407c0f73cc0766282e92b9bc42056a51fbacb0525d77cb1ab5230f8ee0&"
    },
    {
      "name": "プリズミー☆ナイトスター",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1343116493507792977/IMG_7995.jpg?ex=68f53675&is=68f3e4f5&hm=db4e68e2335eb96b392c1eda15cadba800f8afbc337677a5623676afca80bf3d&"
    },
    {
      "name": "プリズミー☆シャイニーリボン",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1343116387148890183/IMG_7994.jpg?ex=68f5365c&is=68f3e4dc&hm=e2f5740516900a5caaecea638e8ad4d87377c7dff74bf8d5c3f3984c81723e03&"
    },
    {
      "name": "ひみつのプリマジまつり",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1343116225764397106/IMG_8004.jpg?ex=68f53636&is=68f3e4b6&hm=dc3c24ed5c76bef99755a0303b8cf18e94c0e141e82b285541413c3a720ee320&"
    },
    {
      "name": "テクノマジカルピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1337762781008756806/IMG_7940.jpg?ex=68f582ed&is=68f4316d&hm=12bbb2d4fba2e79ffbc251fee9c07d25ba5492144d81f19785dec0e12d2be2f8&"
    },
    {
      "name": "ひみつのプリマジひな",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1337762598397018182/IMG_7938.jpg?ex=68f582c1&is=68f43141&hm=16264b0f76223f2e8a46fa6aafe559c316bc8c1c6727f22d4351a0a0bfbf458b&"
    },
    {
      "name": "プリンセスハートフェザー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1337762534442401833/IMG_7937.jpg?ex=68f582b2&is=68f43132&hm=3dafa7e10589d0677b64e7fd619083ccde4b19a5ab055a14021e985569308ffa&"
    },
    {
      "name": "メカニックビート",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1337393428215890031/IMG_4820.jpg?ex=68f57c70&is=68f42af0&hm=371af7570d39e2abde0772229391c8092f8df59229bc7553bd072b7f386b6bf5&"
    },
    {
      "name": "ひみつのプリマジあうる",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1337393398293856328/IMG_4822.jpg?ex=68f57c69&is=68f42ae9&hm=9056699ada070c3cb1769e7c7742c15651ca6883a67736150031aa766a045725&"
    },
    {
      "name": "ひみつのプリマジあまね",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1314792613085188177/IMG_4035.jpg?ex=68f500ca&is=68f3af4a&hm=086c01493c38a6e8bc92ece2634c282c80e5c5efbb915ae19cc015dde7d0b07e&"
    },
    {
      "name": "チアリーダーグリーン",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1313493358785859634/IMG_7701.jpg?ex=68f58cc4&is=68f43b44&hm=3541e2194bea21aaa3e81147cc0043d21bfb341566f3113226192f45f23a4e10&"
    },
    {
      "name": "ミラクル☆キラッツグループキラッと",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1313493269484929075/IMG_7700.jpg?ex=68f58cae&is=68f43b2e&hm=c7b515743da5eda1ead96cb070e25e1c80ce24fb7fbb2f8be7bc23bf5d65e9cf&"
    },
    {
      "name": "ときのコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1307341137060560947/IMG_3792.jpg?ex=68f4ebd0&is=68f39a50&hm=0a7324d4b413ae39aa717d73b41f2b36aa22bd6918f76f853042e2565196a18e&"
    },
    {
      "name": "スイートハニーキラッと",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1307341107734122546/IMG_3793.jpg?ex=68f4ebc9&is=68f39a49&hm=20b6c580371e0f8e72dbf75a6ac241dc6f7359d4e266986a27a210c9adb4c649&"
    },
    {
      "name": "ガールズエールキラッと",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1307339971019014214/IMG_3791.jpg?ex=68f4eaba&is=68f3993a&hm=7e4f004f30b68af1857721db99ffa9e9adf67df9ceda54dd05a0c4f2ebf003d6&"
    },
    {
      "name": "マイ☆ドリームミルキーブルー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1305062707925352468/IMG_7620.jpg?ex=68f5339c&is=68f3e21c&hm=7e9d4446f595bdb49c474b0a31cb5acbeb75fe5c31fd8099ef8b8de44a926856&"
    },
    {
      "name": "マイ☆ドリームミルキーパープル",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1305062675864354866/IMG_7619.jpg?ex=68f53394&is=68f3e214&hm=62b87a7a86db1995aab13497f79cfc40a166c2157506d455864dc09c56ed70c9&"
    },
    {
      "name": "マイ☆ドリームミルキーオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1305062617772982272/IMG_7618.jpg?ex=68f53386&is=68f3e206&hm=e8de4eba6e362659821fc731bf850f5fb2fd38d24469911f0148763a167286a9&"
    },
    {
      "name": "ひみつのプリ☆チャンりんか",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1304945130201157743/IMG_3725.jpg?ex=68f56edb&is=68f41d5b&hm=7576368f5020540514c92836a32c3621d95f891e0d76726b0d893c31f72d40bd&"
    },
    {
      "name": "ひみつのプリ☆チャンみらい",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1304945092108222566/IMG_3724.jpg?ex=68f56ed2&is=68f41d52&hm=74fad6e8db0815e4e41970ab9bec3c8091f4e1f97b19d2c6d4a4b36a8917d0cb&"
    },
    {
      "name": "シークレットアリスキラッと",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1296441095080775680/IMG_7485.jpg?ex=68f57a1b&is=68f4289b&hm=82c21927c5c5e5483203fd832329774c0b2f66efe5f1cfdc69724a6bce967306&"
    },
    {
      "name": "ファンタジータイムドリーム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1296440993251332096/IMG_7486.jpg?ex=68f57a03&is=68f42883&hm=2ba7d59ae4d62732b88f23c4d419247683f044c431d26f15f280dd87648b1f21&"
    },
    {
      "name": "ウィッシュリボンアイドルL",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1289208929020022924/IMG_7425.jpg?ex=68f588a1&is=68f43721&hm=b18a01732e0a9319f2f78bfdc37fa5419d10c5e2b51a20150d2c0e09d375516e&"
    },
    {
      "name": "クリスタルスノープリンセス",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1282318887165366393/IMG_7356.jpg?ex=68f58447&is=68f432c7&hm=4d7422785a8eecf774a93a6d03d6ff5205f403c1d9c3b97d09bf0bd256921515&"
    },
    {
      "name": "ファンタジータイムサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1280153057023496352/102_20240902220711.png?ex=68f58c30&is=68f43ab0&hm=3571837e923eb4da202666a22312ace2c3b4f209f171ab341be6611015a37ff3&"
    },
    {
      "name": "マリオネットミューサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1280153036379127970/102_20240902221027.png?ex=68f58c2b&is=68f43aab&hm=054ff9d0a34fddb5afddcd4d1bf3b63d99d50a784ca1f79f1941897a971c7e4a&"
    },
    {
      "name": "メルティリリィサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1280137148900839425/IMG_7331.jpg?ex=68f57d60&is=68f42be0&hm=8b4cccca421bfa0772fa7aceba147f1357ea55b8e9fdba4b9d75e5fdbf511488&"
    },
    {
      "name": "ネオンドロップサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1279782632544272394/IMG_2919.jpg?ex=68f584b4&is=68f43334&hm=dff8882883bf0f3d9b4700ddb0aef1ed428dcb5a0a3071b32a05c1e5f2b039e6&"
    },
    {
      "name": "ひみつのアイドルタイムみちる",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1276822056171864117/IMG_7297.jpg?ex=68f54b74&is=68f3f9f4&hm=d05100d965b70e7b86c3d00e2bcf9f4f36ae685d31ddda94336a91a35410fbfa&"
    },
    {
      "name": "ひみつのアイドルタイムにの",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1276822023141589024/IMG_7298.jpg?ex=68f54b6c&is=68f3f9ec&hm=c2dfa0dff48f5a5023e5c299a4701bb2f8a4c21cd5e6c14ded5f4600f8118c7f&"
    },
    {
      "name": "エンジェリックファンシー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1276821947505840148/IMG_7296.jpg?ex=68f54b5a&is=68f3f9da&hm=5084c2941beed00bf4959836e6db6c65f927e37ef4160d5b929beb827f5a0bd6&"
    },
    {
      "name": "ウィッシュリボンアイドルM",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1273998966907732079/IMG_7271.jpg?ex=68f4e97f&is=68f397ff&hm=858f39587e3faad4a3b7f41963eadae46526a3968c783bc43f8afd36c420e58d&"
    },
    {
      "name": "ひみつのアイドルタイムゆい",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1271704921783144529/IMG_7243.jpg?ex=68f522c0&is=68f3d140&hm=22fa76fa05212bf88c5785052a15e620ca54c820cbd0297a6d7d5b245c726a9b&"
    },
    {
      "name": "ウィッシュリボンアイドルS",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1271704836924248146/IMG_7242.jpg?ex=68f522ac&is=68f3d12c&hm=690cb486d7cca4de499cb1091d917f7da45458d19b8e2ddcdf0d82758df60c43&"
    },
    {
      "name": "ホリックトリックサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1269167046013485077/IMG_7213.jpg?ex=68f521ab&is=68f3d02b&hm=487ff159938309fc5610b85a3cf3099e63df5f4dd703d1ebe4552cb5de2f305a&"
    },
    {
      "name": "おとめマーガレット",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1269166972885798932/IMG_7212.jpg?ex=68f5219a&is=68f3d01a&hm=316315c00d1e7772a96341f5beffe9debf955bcce268fff50c4a89ff69665708&"
    },
    {
      "name": "ハートフェザー",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1269166190106775667/IMG_7211.jpg?ex=68f520df&is=68f3cf5f&hm=190546ed223ac73b2d3a79e71a1ffcca20cbffc9f9cf31a28d4c4b9307264d1a&"
    },
    {
      "name": "ひみつのプリパラそふぃ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1264568176298037308/101_20240721213913.png?ex=68f58a23&is=68f438a3&hm=c6ceed21289cb8e725dbe5cc62b14a7b9cf87a9658a92d9dc0f04cd44ebdf205&"
    },
    {
      "name": "キャンディアラモードサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1264568071205552138/101_20240721213251.png?ex=68f58a0a&is=68f4388a&hm=f84f8c232b859fe579eb8179cd1b60ae07825652a0849519ce9138e763359ac1&"
    },
    {
      "name": "ひみつのオーロラドリームみおん",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263471606852882472/IMG_7123.jpg?ex=68f58161&is=68f42fe1&hm=8336dffd66e893bd3481ea387c851c62eae6ec73aa56e8e58ac93d0817ead809&"
    },
    {
      "name": "ピュアプレミアムウエディング",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263471593460469820/IMG_7122.jpg?ex=68f5815e&is=68f42fde&hm=a347487073671e834c134884147588f5fdf9d7bd67bc92146ce0dc940cd04a3b&"
    },
    {
      "name": "トゥインクルリボンサイリウム",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263461512920694875/IMG_7094.jpg?ex=68f577fa&is=68f4267a&hm=81c94abe4921bf7698a1704d0cb49db3b7b947f03d57f9d02af83aa61c43ef40&"
    },
    {
      "name": "ひみつのプリパラみれぃ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263461455047561226/IMG_7093.jpg?ex=68f577ec&is=68f4266c&hm=d92763e4dde41e1151df6aece4d65af5dfb282825437d46f28a3e09988a27faf&"
    },
    {
      "name": "プリマジチェックピンク",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263460864581959753/IMG_1487.jpg?ex=68f57760&is=68f425e0&hm=0d909c5a4d2e337791566a5c6a3e862c0333848fd93dfba3aeb94fe8d000b1a4&"
    },
    {
      "name": "ひみつのプリパラらぁら",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263460592669425724/IMG_6861.jpg?ex=68f5771f&is=68f4259f&hm=5e8905e58418c03e94b05868ed39e9be3b8c0ebb3118bf312a06d5e61861c09e&"
    },
    {
      "name": "パラダイス",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263460344441999370/IMG_6865.jpg?ex=68f576e4&is=68f42564&hm=ed67c18ef79b232b17cad87e20423a7888180d3392f38992ff7d21aefe68d6d1&"
    },
    {
      "name": "マナマナみゃむ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263459830123855874/IMG_6651.jpg?ex=68f57669&is=68f424e9&hm=695bf70970d22af13bc97a27c60b2d939a8a7ac92c494b0549d0115a6ff23e93&"
    },
    {
      "name": "ピュアフレッシュウエディング",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263458906630258759/IMG_6522.jpg?ex=68f5758d&is=68f4240d&hm=59c323823d86c2bef2ae86228375522690a00fb19486297f2370ae1a19cf7327&"
    },
    {
      "name": "ピュアホワイトウエディング",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263458868701433920/IMG_6519.jpg?ex=68f57584&is=68f42404&hm=cad49a6e887adfea76ab0dedd282452f95f00c24b00736f09c70377f1cd30e85&"
    },
    {
      "name": "スターシャインベスト",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263458618993283113/101_20240421210658.png?ex=68f57548&is=68f423c8&hm=b154b4cb4cd964721e594776a51f78406d2ccc070adc0b946fd34de94328c72a&"
    },
    {
      "name": "レッドロックベアトップ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263458589885075528/101_20240421210721.png?ex=68f57541&is=68f423c1&hm=c130cae1d0ce9ee5a41882d385cf45da7d442ec22a9c801d709eb054ba117b1d&"
    },
    {
      "name": "ひみつのオーロラドリームあいら",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263458563616018432/101_20240421210735.png?ex=68f5753b&is=68f423bb&hm=f320f6b9001fe323537bb78c63611cfe69af020bf888fc02ad2e3056db6059e1&"
    },
    {
      "name": "ひみつのオーロラドリームりずむ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263456339586453575/IMG_6426.jpg?ex=68f57329&is=68f421a9&hm=d462da2892736f938db2095f4df00effa7126d85c569a2aa33495cb93b488a68&"
    },
    {
      "name": "プリマジチェックヘブンズホワイト",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263455972228333588/IMG_6424.jpg?ex=68f572d1&is=68f42151&hm=33bb8c005aa62fa8069de467eb4f308dea0f965e314e6027bf846c17dae874bf&"
    },
    {
      "name": "フレッシュピンクベアトップ",
      "url": "https://cdn.discordapp.com/attachments/1263454721075581009/1263455715817820170/IMG_0374.jpg?ex=68f57294&is=68f42114&hm=29f2fad3af9e22063d997528724491b855d8a238c839f2f12888b10283822047&"
    },
    {
      "name": "ときせん ひとちゃん コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1421727017115586611/IMG_8926.jpg?ex=68f51cb7&is=68f3cb37&hm=a17e144abb8fabe158351e17511ffd97990daafdf9206c68702ed9241c04cb88&"
    },
    {
      "name": "ときせん あきちゃん コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1421684940931862539/IMG_7303.jpg?ex=68f4f587&is=68f3a407&hm=e6c94cade57cd960e7b09136af62093226fff60ed8299ce05f6b5e2f5f3b54c1&"
    },
    {
      "name": "ときせん おはる コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1396755872482594909/IMG_6636.jpg?ex=68f53c06&is=68f3ea86&hm=e343ace88061dd8090bcf66b9511e561807d30015c78cb24ab80584ac6b4da7b&"
    },
    {
      "name": "ときせん ジュリ コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1367044878948630528/IMG_8420.jpg?ex=68f54081&is=68f3ef01&hm=d9f0527c95f0ed1c3f0d5aac59d975e67cb3e120c81fc934e910bb6f935dcf0c&"
    },
    {
      "name": "ときせん かなみん コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1367044790532706305/IMG_8419.jpg?ex=68f5406c&is=68f3eeec&hm=7c0e7ae85982e087c5affba28a6df06eb2489fafc272f6d2e4ead72b8f090667&"
    },
    {
      "name": "さくらミクコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1367044393479176283/IMG_8416.jpg?ex=68f5400d&is=68f3ee8d&hm=99bc3e2eae40a961f4721f2fbbb97dcfec72e6848bb34a4bfa6bcde314131355&"
    },
    {
      "name": "ひみつのミラクルTシャツ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1343485515135062077/IMG_5135.jpg?ex=68f53ca3&is=68f3eb23&hm=17781ea06b290d644abd01a3b9d747adbd8617ff1bc5baca81dd42d2c6514a23&"
    },
    {
      "name": "ウィンターTシャツ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1337393516325900359/IMG_4816.jpg?ex=68f57c85&is=68f42b05&hm=e6cd13b5bc400bea965be649270af999133f2572041828f02b4b763db5d76c9d&"
    },
    {
      "name": "オータムTシャツ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1307341191540641852/IMG_3796.jpg?ex=68f4ebdd&is=68f39a5d&hm=da7eefbf0e5af914955cbac95e4192e4f5c74ba4c06be9011a96271db1a625b2&"
    },
    {
      "name": "Pまるさま。コーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1269167431180484639/IMG_7221.jpg?ex=68f52207&is=68f3d087&hm=90646e4825fe9a61b872cf2d09239a0c7c9b66079ebfb38fc7566473a6dfb933&"
    },
    {
      "name": "レイニーツアーひがし",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1264126174041477202/IMG_2411.jpg?ex=68f53ffe&is=68f3ee7e&hm=dab203a97aece21fe8da3b301944064fbc90b37b5ebea1f8a249dd57cf0f68ca&"
    },
    {
      "name": "レイニーツアーにし",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263471070695129149/IMG_2383.jpg?ex=68f580e1&is=68f42f61&hm=296ebafbc3117a78992b2ee05d1be526246ed71891d41d31ca860dfdf686f300&"
    },
    {
      "name": "スプリングツアーぜんこく",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263461139875102720/IMG_1488.jpg?ex=68f577a1&is=68f42621&hm=94865539a001fb85205bb1a6003e4e6dfc69a3328147fe964072fa64acdd655b&"
    },
    {
      "name": "はつねミクコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263460491670458439/IMG_6863.jpg?ex=68f57707&is=68f42587&hm=96c06152332f956d18d8ffa0b3c08a25ff165e6449911c849a8c08cdfd714884&"
    },
    {
      "name": "ひみつのはつねミクコーデ",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263460452579409931/IMG_6864.jpg?ex=68f576fd&is=68f4257d&hm=e74b91245138e1e5959c70e2831b0a3d6817fd146df71b5f7c834e2ae3631860&"
    },
    {
      "name": "スプリングツアーひがし",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263459773194702908/IMG_1026.jpg?ex=68f5765b&is=68f424db&hm=49982d4fb27c26c5539c0c48cd600b0e7119ada967a73934c3dd13ce1a193d0c&"
    },
    {
      "name": "スプリングツアーにし",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263458213597155460/IMG_0535.jpg?ex=68f574e8&is=68f42368&hm=7b5305f8acabfa8d5276c5c97918f22b27d04ba0c28e8a85e11930a40ffa682e&"
    },
    {
      "name": "パラダイスがくえんせいふく",
      "url": "https://cdn.discordapp.com/attachments/1263454745830363148/1263456422046334997/IMG_6427.jpg?ex=68f5733c&is=68f421bc&hm=3e7afbce88b62d4f65b5c19b9b83e4ffa859b36142648c586c97ff8cea042650&"
    },
    {
      "name": "おとぎばなしかぐやひめピュアピンク",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1424202035640926319/IMG_7356.jpg?ex=68f58c01&is=68f43a81&hm=7a8ef513f8d81c095da5eab989f27ef0cc73b22952f92ac89b92e4ec25702712&"
    },
    {
      "name": "おとぎばなしアラビアンナイトブルー",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1421726445746786385/IMG_8931.jpg?ex=68f51c2f&is=68f3caaf&hm=a210f7f3cdba646e658515fffd5255012ee5dd9bc6e546234d12fbb0d358ed31&"
    },
    {
      "name": "おとぎばなしアラビアンナイトピンク",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1421726425064538164/IMG_8932.jpg?ex=68f51c2a&is=68f3caaa&hm=cfc9113d397eecbbc471b0888501dd39c748accf30abdd59a49cb42a11f2135e&"
    },
    {
      "name": "しあわせナース",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1421687617358921778/IMG_7304.jpg?ex=68f4f805&is=68f3a685&hm=01fde2e71c212b5e25d47ffd5fd00cbc0231e6eee33844ed5469e0afba5e6c03&"
    },
    {
      "name": "おとぎばなしシンデレラピンク",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1396821388253466736/IMG_6643.jpg?ex=68f5790a&is=68f4278a&hm=5bed2564697dda4bf4c72aec4f611057fe78cb6635a81b78ab352563ac501a92&"
    },
    {
      "name": "おとぎばなしかぐやひめ",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1396821345966489741/IMG_6642.jpg?ex=68f57900&is=68f42780&hm=02d62b416472a95ee77e2adc9885c8d81678de232a6b2385465e9dde77a02f24&"
    },
    {
      "name": "わくわくベーカリー",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1396757972008435853/IMG_8762.jpg?ex=68f53dfb&is=68f3ec7b&hm=741c2ee74410979adcd2d1fc36034c4c6d8ec07ebbe3a65ab55f461f36e03dec&"
    },
    {
      "name": "おとぎばなしワンダーランド",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1367043964506734593/IMG_8413.jpg?ex=68f53fa7&is=68f3ee27&hm=c541bbde2259159260ca10672582287ce8e601f6362d68df30a70246da9f639a&"
    },
    {
      "name": "おとぎばなしアラビアンナイトレッド",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1367030946636759071/IMG_8394.jpg?ex=68f53387&is=68f3e207&hm=5ee89819c07ce1fefcb35b8c6a80347b15be1a4df94fb236bf98f63e24ea222c&"
    },
    {
      "name": "こいのクリスタルピンク",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1358301427671236780/IMG_8260.jpg?ex=68f51588&is=68f3c408&hm=dbd3c48477ee5fd95812a8fa5e553dbb3afd7d9f07b17cfff0154380c7437dd8&"
    },
    {
      "name": "おとぎばなしアラビアンナイト",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1357685441465286756/IMG_8249.jpg?ex=68f57ad9&is=68f42959&hm=b08c908ae509d97812055bb09b2f8ee46ece644ab105306c4f2f14b6ff262f5b&"
    },
    {
      "name": "いてざサファイア",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1343481971786911754/IMG_5129.jpg?ex=68f53956&is=68f3e7d6&hm=a2149ae4e77712abc7e453af8b4ddb0fb4b627cd8f31ebd52c597b926e006e08&"
    },
    {
      "name": "おとぎばなしピーターパンレッド",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1312032638206349334/IMG_3946.jpg?ex=68f5825d&is=68f430dd&hm=cae25024cf75836eafe9f258790e81372630774b89eac68f0c2a73f3c4faef7a&"
    },
    {
      "name": "てんびんざターコイズ",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1296440585686618146/IMG_7482.jpg?ex=68f579a2&is=68f42822&hm=78fa3e12f2248577cd28f7b6d8288afc458631fb0bfe905f9f3db1f7de01e873&"
    },
    {
      "name": "おとめざカーネリアン",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1290653816223432745/IMG_7442.jpg?ex=68f58448&is=68f432c8&hm=1f894bf802a7861fd5e7c8d92d24e324cdad9637720a1dfd75fd45a4d9a87db3&"
    },
    {
      "name": "おとぎばなしあかずきんイエロー",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1282322759485227060/IMG_2984.jpg?ex=68f587e2&is=68f43662&hm=af3a74ce6bf81b2a78ebb2592966bc98fc1d3aadabf675dad383582915837d3a&"
    },
    {
      "name": "ししざダイヤモンド",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1282318718017474620/IMG_7351.jpg?ex=68f5841e&is=68f4329e&hm=fc5c5a49601d71edefbe2f3bf48849f91f23a658df3a8366420e50c6e7ef85df&"
    },
    {
      "name": "おとぎばなししらゆきひめ",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1269167286112092171/IMG_7219.jpg?ex=68f521e4&is=68f3d064&hm=0e4349b101c77a10e825dc751072973de41d63ff8a6ddf0673aafd2d02cead47&"
    },
    {
      "name": "おとぎばなししらゆきひめポイズン",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1268911525922472069/IMG_7201.jpg?ex=68f58533&is=68f433b3&hm=44eaeba9e16b751a67d1c03a93f7b469eca556255efe4a0ba297287f5ab4e597&"
    },
    {
      "name": "ふたござシトリン",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1264568430690832487/101_20240721214824.png?ex=68f58a60&is=68f438e0&hm=c0123a8a5cecc939bc926b1dc8f3b118fc17732a1eb8e17e8058786021087246&"
    },
    {
      "name": "おとぎばなしシンデレライエロー",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1263473548618367067/IMG_7130.jpg?ex=68f58330&is=68f431b0&hm=9f381233ee720a30b73aace47e721f51eb134d3c9b704577873c1649d640ec67&"
    },
    {
      "name": "おとぎばなしシンデレラ",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1263473528880103445/IMG_7132.jpg?ex=68f5832b&is=68f431ab&hm=43fd1bfdbbd41ebd8ed7595da8b3bb660efa017b60835f3da796c1c7183294a6&"
    },
    {
      "name": "おうしざエメラルド",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1263468628104314952/IMG_2375.jpg?ex=68f57e9b&is=68f42d1b&hm=176b6bfee432b9ddd8a01373328246bdd506903b8074c16a7a61c14f4a44a854&"
    },
    {
      "name": "おひつじざルビー",
      "url": "https://cdn.discordapp.com/attachments/1263460076107202601/1263460131430207581/IMG_6870.jpg?ex=68f576b1&is=68f42531&hm=11aad61d50bb4294dadb13ef27cf0db07c225bc5507c87121c14961c635cb587&"
    },
    {
      "name": "ときめきハロウィンブルー",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1428988330346811514/IMG_7443.jpg?ex=68f52957&is=68f3d7d7&hm=1336e623ab2bfa90e3e6a2e82d332552e60354fffced2118dd4d76fafc022c68&"
    },
    {
      "name": "ときめきハロウィンオレンジ",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1424201928157429840/IMG_7355.jpg?ex=68f58be8&is=68f43a68&hm=e54c3f5093bb1e71bc740308bc9d95a029ab0b2123c36c77024acb5da9c050b9&"
    },
    {
      "name": "エターナルジュエルラブジュリエル　える",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1421726849985286196/IMG_8930.jpg?ex=68f51c8f&is=68f3cb0f&hm=3841c9dcc46b09410af4c71924bfc1b1c7449f59ac606e5eb7a7e62b1fb17e12&"
    },
    {
      "name": "エターナルジュエルラブジュリエル　じゅりあ",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1421726840086593587/IMG_8929.jpg?ex=68f51c8d&is=68f3cb0d&hm=11b8dabfff0da7f7cc439dfc4887b0a53656037edb0bf238853f1e6e06ac4685&"
    },
    {
      "name": "ときめきビジューツイン　える",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1396758273889402972/IMG_8764.jpg?ex=68f53e43&is=68f3ecc3&hm=a41cb878d7b167616956afe53810dd829c2be2ba6b7e22c0d53dcef1932a5c36&"
    },
    {
      "name": "スポーティバレエコアミント",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1396755541258407936/IMG_6635.jpg?ex=68f53bb7&is=68f3ea37&hm=f40fa93ad68603064f2b9dbe95abff4657c68bfc98ef4743fcc9f5b5c8ff3d53&"
    },
    {
      "name": "ときめきビジューツイン　じゅりあ",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1396755241915121734/IMG_6634.jpg?ex=68f53b70&is=68f3e9f0&hm=dccefa8559dbc70f6c97b3b1a27a404b866da0097852f97d9dbfa7c142d5ddd1&"
    },
    {
      "name": "スポーティバレエコア",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1393204859452391555/IMG_6420.jpg?ex=68f57fe2&is=68f42e62&hm=b60d7418ec3a85a1d867185b83c80ff3defe893690a6b5c9aa00023c6783d9a2&"
    },
    {
      "name": "ハローキティ なかよし",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1393204593999085708/IMG_6419.jpg?ex=68f57fa3&is=68f42e23&hm=a582d89638af9a5b71103dd3c96de66069bf2c50d8c4217c72bd07d268b288ae&"
    },
    {
      "name": "シナモロール なかよし",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1393204428454101102/IMG_6418.jpg?ex=68f57f7c&is=68f42dfc&hm=0a4fc0a2ff65e2cd3aa1a1ae311d5490e3e8bf573e0e9ac9971300c101b22daf&"
    },
    {
      "name": "フィーバーエンジェル",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1376168805415260322/IMG_8496.jpg?ex=68f57c53&is=68f42ad3&hm=7c78c888df2b66d688b635d3ef27c29f5e1b0a39df773993c57bba2f38a87bbe&"
    },
    {
      "name": "フィーバーデビル",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1373484248400527480/IMG_6068.jpg?ex=68f4f2a2&is=68f3a122&hm=caff2acf296b0597a02241bd42252a972e89cde0a6761fa83f3df5da31888b13&"
    },
    {
      "name": "ベリキューデニムラブ",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1362419653850169547/IMG_8309.jpg?ex=68f5906e&is=68f43eee&hm=e0a096dc0e9fbf6d5dff2ccd0c594c798e9b9661b5646dbf5e99196e6de9a711&"
    },
    {
      "name": "ジュエルバズリウムアクアマリン",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1360951286371188808/IMG_8303.jpg?ex=68f57ee7&is=68f42d67&hm=d6edf2401596deeae2fce751eb1ab077eeffd5c676c5c8e6e95392d481cf552e&"
    },
    {
      "name": "ジュエルバズリウムダイヤ",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1360939744212811847/IMG_5783.jpg?ex=68f57428&is=68f422a8&hm=e73d90c1ce6e9ba71becaa53099bbe15ece714f018625e01b7eb6df5c2af14d1&"
    },
    {
      "name": "ベリキューデニムラブパープル",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1358062237998256310/IMG_5610.jpg?ex=68f58845&is=68f436c5&hm=29cce34721dad775a00c65ea167a6dbc82ff61d53d63617d2783591b77db816b&"
    },
    {
      "name": "ベリキューデニム",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1358062211800502344/IMG_5611.jpg?ex=68f5883e&is=68f436be&hm=a1f386ed32d603a1e9ccb58a8be34b717598f44ec24c4d15802a48accff826c5&"
    },
    {
      "name": "ベリキューデニムピンク",
      "url": "https://cdn.discordapp.com/attachments/1357323052957831329/1357323102270390372/IMG_5582.jpg?ex=68f57ae5&is=68f42965&hm=710cca482c230ea65bc88e47226987355a35b17c32a5f5ba653035df6c7e4ea6&"
    },
    {
      "name": "エターナルスペースジャンピンロケットクール",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1421726960383557692/IMG_8927.jpg?ex=68f51ca9&is=68f3cb29&hm=fd141fb3bc870e3580222b1be7d025c4280c5310ed40c22aed650c56f8a6c843&"
    },
    {
      "name": "エターナルスペースジャンピンロケットラブリー",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1421726945292587008/IMG_8928.jpg?ex=68f51ca6&is=68f3cb26&hm=8cc50bc09c79c0c5ff65b4c73974b4fe5c539ec5deee4495b0bc0cc54d72c0ef&"
    },
    {
      "name": "あこがれコズミックツイン　おとめ",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1421684587096178748/IMG_7299.jpg?ex=68f4f533&is=68f3a3b3&hm=b6beca4f135a7e5bb86326ebdf72bba8bc3a02ad06a85145e909149bf924bdcc&"
    },
    {
      "name": "スクールメイツクールミント",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1405682151508152350/IMG_6907.jpg?ex=68f56885&is=68f41705&hm=5714c559181f32abae20c58f80593cd6e4c5ec5a36c2aa0143c08cc37a1b174e&"
    },
    {
      "name": "スペースダイナー",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1396757575982383125/IMG_8759.jpg?ex=68f53d9c&is=68f3ec1c&hm=9eee8789f6c9f439e717901a498004bb5ae6953f926c16d2ed257dade4c1d1b2&"
    },
    {
      "name": "ハッピーバースデー！すばる",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1396757481941893230/IMG_8758.jpg?ex=68f53d86&is=68f3ec06&hm=2b312704d84486377eaf3cc2f03a9dc005fc574575523d92d79b653df350ef20&"
    },
    {
      "name": "スペースダイナーレッド",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1396756213370458193/IMG_6637.jpg?ex=68f53c57&is=68f3ead7&hm=18b30194e2baae904fdfc0dba80f57c99bc78c1e1e0dda63a74109d1254fc733&"
    },
    {
      "name": "スクールメイツラブリー",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1396754853719445645/IMG_6633.jpg?ex=68f53b13&is=68f3e993&hm=52e9c72bdb9358d95767551c7b4a30ad7b434e81319b2bd83ec96182582967f6&"
    },
    {
      "name": "スクールメイツクール",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1396754831200354394/IMG_6631.jpg?ex=68f53b0e&is=68f3e98e&hm=4226814476e6edb62b96ca11fb42d2f6d5b63700e3dac5f401e58abdab19cd32&"
    },
    {
      "name": "アイドルチェックラブリー",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1393207256409047152/IMG_8655.jpg?ex=68f5821e&is=68f4309e&hm=d40d2a513c448cc591a97a0b6e3a4d3650b6ba30a61752725b71c7b6cde80eda&"
    },
    {
      "name": "ポチャッコ なかよし",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1393204353447366686/IMG_6417.jpg?ex=68f57f6a&is=68f42dea&hm=3139e423d13221e8fec3ce0b4c4c5865bb76dae386cbc8e61af03e55376c8e55&"
    },
    {
      "name": "ポムポムプリン なかよし",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1388281990159269981/IMG_6309.jpg?ex=68f5635b&is=68f411db&hm=8be0ad9827639b4f56d13c8495a2e3c3269a71575518afa582acb908c69ce74c&"
    },
    {
      "name": "スペースバズリウムギャラクシー",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1383785523440783524/IMG_8544.jpg?ex=68f58272&is=68f430f2&hm=96c585f45772ba081a3705b63739f56fdd2c0d995ca17321a1cdef41cd3dbbfd&"
    },
    {
      "name": "アイドルチェッククール",
      "url": "https://cdn.discordapp.com/attachments/1374733216056868864/1383785406117707897/IMG_8547.jpg?ex=68f58256&is=68f430d6&hm=7511d8d714eee055db8c87c50c8c02e5abf699fb487b48e091b66cec6fb2cc03&"
    },
    {
      "name": "フラワーバズリウムカンパニュラ",
      "url": "https://cdn.discordapp.com/attachments/1396756478131568680/1424202122471149642/IMG_7357.jpg?ex=68f58c16&is=68f43a96&hm=f5cb07e02f9d4fd685369756a32682df3489c6f18541a553435d8699094d45db&"
    },
    {
      "name": "プリンセスアイプリバズリウム",
      "url": "https://cdn.discordapp.com/attachments/1396756478131568680/1396756534528315412/IMG_8398.jpg?ex=68f53ca4&is=68f3eb24&hm=6cb346cdf25da29e4e7c13cacfa06a2cbdb9187c3a78ef11866e49dea3cadbf4&"
    }
  ]
}